let isHolding = false
let longPressDuration = 500
let timer = null
let duration = 100
let minDuration = 50
let counter = 0

const isTouchSupported = 'ontouchstart' in window
const startEvent = isTouchSupported ? 'touchstart' : 'mousedown'
const endEvent = isTouchSupported ? 'touchend' : 'mouseup'

export default function (element, options) {
  const holdRelease = function (event) {
    document.removeEventListener(endEvent, holdRelease)
    document.onselectstart = null
    reset()
    clearTimeout(timer)
    if (options.end) {
      options.end(event)
    }
  }
  const startCounter = function () {
    timer = setTimeout(() => {
      const flag = options.counter(++counter)
      if (!flag) {
        holdRelease()
        return
      }
      if (counter % 3 === 0) {
        duration = (duration / 2 > minDuration) ? duration / 2 : minDuration
      }
      startCounter()
    }, duration)
  }
  const reset = function () {
    isHolding = false
    duration = 100
    counter = 0
  }
  element.addEventListener(startEvent, function (event) {
    if (isHolding) return

    document.onselectstart = function () { return false }

    document.addEventListener(endEvent, holdRelease)

    timer = setTimeout(() => {
      isHolding = true
      clearTimeout(timer)
      if (options.start) {
        options.start(event)
      }
      if (options.counter) {
        startCounter()
      }
    }, longPressDuration)
  })
}
