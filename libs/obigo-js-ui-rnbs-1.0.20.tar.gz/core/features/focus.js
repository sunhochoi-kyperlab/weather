/**
 * @module focus
 * @desc focus module create focus map and control
 */
import appManager from './appManager'
import {hardkeyCode, hardkeyInstance as hardkey} from './hardkey'
import Events from '../features/events'

const APP_TYPE = { 'GADGET': 'gadget', 'WIDGET': 'widget' }
const POPUP_TYPE = { 'NONE': 'none', 'CONTEXT': 'context' }
const ROTATE_RIGHT = 'right'
const ROTATE_LEFT = 'left'

class Focus {
  constructor () {
    this.appManager = appManager
    this._focusMap = new Map()
    this._lastFocusMap = new Map()
    this._binded = false

    this._currentScene = 0
    this._currentZone = 2 // only 2 or 3
    this._currentOrder = 0

    this._Loop = true

    this._zoneFocusMode = false
    this._componentFocusMode = false
    this._componentControlMode = false

    this._hardkeyCode = 1000
    this._hardkeyMode = 0
    this._appType = APP_TYPE.WIDGET

    this._popupType = POPUP_TYPE.NONE
    this._popupZoneStyle = {}
    this._$focusZoneEle = null

    this._onBodyClickListener = this._onBodyClickListener.bind(this)
    this.prevZone = this.prevZone.bind(this)
    this.nextZone = this.nextZone.bind(this)
    this._onRotaryLeftRight = this._onRotaryLeftRight.bind(this)
    this._handleRotateClick = this._handleRotateClick.bind(this)
    this.exitFocusMode = this.exitFocusMode.bind(this)
    this._handleRotate = this._handleRotate.bind(this)
    this._handleWheelEvent = this._handleWheelEvent.bind(this)
  }

  /**
   * @ignore
   * @function _bind
   * @desc bind hardkey/event-bus event
   * @private
   */
  _bind () {
    // hardkey event listener
    if (this._binded) { return } else { this._binded = true }

    // hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_UP, this.prevZone)
    // hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_DOWN, this.nextZone)
    //
    // hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_LEFT, this._onRotaryLeftRight)
    // hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_RIGHT, this._onRotaryLeftRight)
    //
    // hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ENTER, this._handleRotateClick)
    //
    // hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_BUTTON_HOME, this.exitFocusMode)
    // hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_BUTTON_BACK, this.exitFocusMode)
    //
    // if (this.appManager) {
    //   hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleRotate)
    //   this._appType = (this.appManager.type === 2) ? APP_TYPE.GADGET : APP_TYPE.WIDGET
    // } else {
    //   hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleWheelEvent)
    // }

    // event bus listener
    Events.$on('scene:update', (scene) => {
      this.setScene(scene)
    })

    // popup event listener
    Events.$on('popup:show', (obj) => {
      if (!obj.el) return
      this._setZoneFocusOff()
      this._setComponentFocusOff()
      const popupRect = obj.el.getBoundingClientRect()
      this._popupType = obj.type
      this._popupZoneStyle = {
        'height': popupRect.height,
        'width': popupRect.width,
        'left': popupRect.left,
        'top': popupRect.top
      }

      this._lastFocusMap.set(obj.type, obj.prevFocusPosition)

      if (this._zoneFocusMode || this._componentFocusMode) {
        this.startFocusMode() // keep focus mode

        window.removeEventListener('click', this._onBodyClickListener)
      }
    })

    Events.$on('popup:hide', (obj) => {
      this._setZoneFocusOff()
      this._setComponentFocusOff()
      this._popupType = POPUP_TYPE.NONE
      this._popupZoneStyle = {}

      if (this._zoneFocusMode || this._componentFocusMode) {
        const lastPosition = this._lastFocusMap.get(obj.type)
        let lastOrder = (lastPosition.zone === 2 && lastPosition.order > 0 && this._isTargetAvailable(lastPosition.scene, lastPosition.order)) ? lastPosition.order : -1
        this.startFocusMode(true, lastOrder)
      }
    })

    Events.$on('list:scrollstart', this.exitFocusMode)

    Events.$on('focus:control-get', (obj) => {
      this._unbindRotateListener()
      this._componentControlMode = true
    })
    Events.$on('focus:control-loss', (obj) => {
      this._bindRotateListener()
      this._componentControlMode = false
    })

    Events.$on('tab:update', (obj) => {
      if (this._componentFocusMode || this._zoneFocusMode) {
        this._setZoneFocusOff()
        this._setComponentFocusOff()
        if (obj.isFocus) {
          this._currentZone = 3
          this._currentOrder = obj.currentIndex
          this._setZoneFocusOn(3)
          this._setComponentFocusOn()
        } else {
          this.startFocusMode()
        }
      }
    })

    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_BUTTON_BACK, () => {
      if (this._appType === APP_TYPE.GADGET && this._componentFocusMode) {
        this.exitFocusMode()
        this._sendRemainTick(1)
      }
    })

    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_BUTTON_HOME, () => {
      if (this._componentFocusMode) {
        this.exitFocusMode()
        this._sendRemainTick(1)
      }
    })
  }

  _bindRotateListener () {
    if (this.appManager) {
      hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleRotate)
    } else {
      hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleWheelEvent)
    }
    hardkey.addHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ENTER, this._handleRotateClick)
  }

  _unbindRotateListener () {
    if (this.appManager) {
      hardkey.removeHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleRotate)
    } else {
      hardkey.removeHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ROTATE, this._handleWheelEvent)
    }
    hardkey.removeHardkeyListener(hardkeyCode.code.HARDKEY_ROTARY_ENTER, this._handleRotateClick)
  }

  /**
   * @ignore
   * @function _handleRotate
   * @param code keycode
   * @param mode keytype
   * @param tick remaintick
   * @desc event handler - csw:rotate
   * @private
   */
  _handleRotate ({code, mode, tick}) {
    // store key codes for send remainTick
    this.hardkeyCode = code
    this.hardkeyMode = mode

    if (tick === 0) {
      this.exitFocusMode()
      this._sendRemainTick(0)
      return
    }

    if (!this._zoneFocusMode && !this._componentFocusMode && this._appType !== APP_TYPE.GADGET) {
      this.startFocusMode()
      this._sendRemainTick(0)
      return
    } else if (this._appType === APP_TYPE.GADGET && !this._zoneFocusMode) { // gadget focus mode start
      this._zoneFocusMode = true
      this._setZoneFocusOn()
      this._sendRemainTick(1)

      window.addEventListener('click', this._onBodyClickListener)

      return
    }

    // zone focus mode
    if (!this._componentFocusMode) {
      if (this._appType === APP_TYPE.GADGET) {
        this.exitFocusMode()
        this._sendRemainTick(1)
        return
      }

      if (mode === hardkeyCode.mode.HARDKEY_MODE_RIGHT) {
        this.nextZone()
      } else {
        this.prevZone()
      }
      return
    }

    // component focus mode
    if (mode === hardkeyCode.mode.HARDKEY_MODE_RIGHT) {
      this.nextOrder(tick)
      return
    } else {
      this.prevOrder(tick)
      return
    }
  }

  /**
   * @ignore
   * @function _handleWheelEvent
   * @desc event handler for pc environment
   * @private
   */
  _handleWheelEvent (e) { // for pc environment
    const mode = e.mode
    if (!this._zoneFocusMode && !this._componentFocusMode && this._appType !== APP_TYPE.GADGET) {
      this.startFocusMode()
      this._sendRemainTick(0)
      return
    } else if (this._appType === APP_TYPE.GADGET && !this._zoneFocusMode) { // gadget focus mode start
      this._zoneFocusMode = true
      this._setZoneFocusOn()
      this._sendRemainTick(1)

      window.addEventListener('click', this._onBodyClickListener)

      return
    }

    // zone focus mode
    if (!this._componentFocusMode) {
      if (mode === hardkeyCode.mode.HARDKEY_MODE_RIGHT) {
        this.nextZone({})
      } else {
        this.prevZone({})
      }
      return
    }

    // component focus mode
    if (mode === hardkeyCode.mode.HARDKEY_MODE_RIGHT) {
      this.nextOrder()
      return
    } else {
      this.prevOrder()
      return
    }
  }

  /**
   * @ignore
   * @function _handleRotateClick
   * @param code keycode
   * @param mode keytype
   * @desc event handler - csw:click
   * @private
   */
  _handleRotateClick ({code = 1000, mode = 0}) {
    // store key codes for send remainTick
    this._hardkeyCode = code
    this._hardkeyMode = mode

    if (!this._zoneFocusMode && !this._componentFocusMode) {
      this.startFocusMode()
      this._sendRemainTick(0)
      return
    }

    if (this._zoneFocusMode) {
      if (!this._componentFocusMode) {
        // start component focus mode
        this._currentOrder = this._getClosestFocusableComponent(0) // find closest focusable component
        if (this._currentOrder === -1) {
          this.exitFocusMode()
          this._sendRemainTick(1)
        } else {
          this._componentFocusMode = true
          // this._setZoneFocusOff()
          this._setComponentFocusOn()
          this._sendRemainTick(0)
        }
      } else {
        // component click
        const target = this._getCurrentTarget()
        if (target) {
          const $target = target.el

          if (target.vnode && target.vnode.componentInstance) { // emit event for vue-component
            target.vnode.componentInstance.$emit('click', {
              'view': window,
              'bubbles': true,
              'cancelable': false,
              'currentTarget': $target,
              'isFocus': true
            })
            target.vnode.componentInstance.$emit('jog-click', {}) // emit event for slider
          } else { // create click event for html element
            const clickEvent = new MouseEvent('click', {
              'view': window,
              'bubbles': true,
              'cancelable': false,
              'currentTarget': $target,
              'isFocus': true,
              'isTrusted': false
            })
            $target.dispatchEvent(clickEvent)
            const jogClickEvent = new CustomEvent('jog-click', {
              'detail': {}
            })
            $target.dispatchEvent(jogClickEvent)
          }
        }
        this._sendRemainTick(0)
      }
    }
  }

  /**
   * @ignore
   * @function _onBodyClickListener
   * @desc exit focus mode when click screen
   * @private
   */
  _onBodyClickListener () {
    this.exitFocusMode()
    this._sendRemainTick(1)
  }

  /**
   * @ignore
   * @function _onRotaryLeftRight
   * @param code
   * @param mode
   * @desc exit focus mode when click csw:left or csw:right
   * @private
   */
  _onRotaryLeftRight ({code = 1000, mode = 0}) {
    this._hardkeyCode = code
    this._hardkeyMode = mode

    if (this._appType === APP_TYPE.GADGET) {
      this.exitFocusMode()
      this._sendRemainTick(1)
      return
    }

    if (!this._zoneFocusMode && !this._componentFocusMode && this._appType !== APP_TYPE.GADGET) {
      this.startFocusMode()
      this._sendRemainTick(0)
      return
    }
  }

  _findDefaultComponent () {
    const sceneMap = this._getCurrentSceneMap()
    let n = 0
    if (sceneMap) {
      let size = sceneMap.size
      while (n++ < size) {
        const item = sceneMap.get(n)
        if (item && item.isFocus) return n
      }
    }
    return -1
  }
  /**
   * @function startFocusMode
   * @param componentFocusOn [false]
   * @param lastFocusOrder [-1]
   * @example
   * this.$focus.startFocusMode()
   */
  startFocusMode (componentFocusOn = true, lastFocusOrder = -1) {
    this._zoneFocusMode = true
    this._currentZone = 2

    const defaultComponentOrder = this._findDefaultComponent()

    this._currentOrder = (defaultComponentOrder > -1) ? defaultComponentOrder : lastFocusOrder
    if (!this._isTargetAvailable(this._currentScene, this._currentOrder)) {
      this._currentOrder = this._getClosestFocusableComponent(0) // find closest focusable component
    }

    if (this._currentOrder === -1 && this._popupType === POPUP_TYPE.NONE) {
      this._currentZone = 3
      this._currentOrder = this._getClosestFocusableComponent(0) // find closest focusable component
    }

    this._setZoneFocusOn(this._currentZone)

    if (componentFocusOn) {
      this._componentFocusMode = true
      this._setComponentFocusOn()
    }

    window.addEventListener('click', this._onBodyClickListener)
  }

  /**
   * @function exitFocusMode
   * @desc exit focus mode
   * @example
   * this.$focus.exitFocusMode()
   */
  exitFocusMode () {
    this._setZoneFocusOff()
    this._setComponentFocusOff()
    this._zoneFocusMode = false
    this._componentControlMode = false
    this._componentFocusMode = false
    this._currentZone = 2
    this._currentOrder = -1
    window.removeEventListener('click', this._onBodyClickListener)
    console.log('[obigo-ui] exit focus mode')
  }

  /**
   * @ignore
   * @function _setZoneFocusOn
   * @param zone
   * @desc create and add focus-zone element and set style and class
   */
  _setZoneFocusOn (zone = 2) {
    const zoneClass = (zone === 2) ? 'two' : 'three'
    const isExitZoneFocus = (document.body.getElementsByClassName('zone-focus').length !== 0)

    this._$focusZoneEle = (isExitZoneFocus) ? this._$focusZoneEle : document.createElement('div')
    this._$focusZoneEle.classList = []
    this._$focusZoneEle.classList.add('zone-focus', zoneClass, this._appType, this._popupType)

    if (this._popupType !== POPUP_TYPE.NONE) {
      this._$focusZoneEle.style.height = this._popupZoneStyle.height + 'px'
      this._$focusZoneEle.style.width = this._popupZoneStyle.width + 'px'
      this._$focusZoneEle.style.top = this._popupZoneStyle.top + 'px'
      this._$focusZoneEle.style.left = this._popupZoneStyle.left + 'px'
    }

    if (!isExitZoneFocus) document.body.appendChild(this._$focusZoneEle)

    Events.$emit('focus:zone-focus-in')
  }

  /**
   * @ignore
   * @function _setZoneFocusOff
   * @desc remove zone-focus element from body
   */
  _setZoneFocusOff () {
    if (document.body.getElementsByClassName('zone-focus').length === 0) {
      window.removeEventListener('click', this._onBodyClickListener)
      return
    }
    document.body.removeChild(this._$focusZoneEle)
  }

  /**
   * @function nextZone
   * @desc move to next zone area
   * @example
   * this.$focus.nextZone()
   */
  nextZone () {
    if (this._appType === APP_TYPE.GADGET) {
      this.exitFocusMode()
      this._sendRemainTick(1)
      return
    }

    if (!this._zoneFocusMode && !this._componentFocusMode) {
      this.startFocusMode()
      this._sendRemainTick(0)
      return
    }

    this._setComponentFocusOff()

    if (this._currentZone === 2 && this._popupType === POPUP_TYPE.NONE) {
      this._$focusZoneEle.classList.remove('two')
      this._$focusZoneEle.classList.add('three')
      this._currentZone += 1
      this._componentFocusMode = true
      this._currentOrder = this._getClosestFocusableComponent(0) // find closest focusable component
      this._setComponentFocusOn()
      this._sendRemainTick(0)
    } else {
      this.exitFocusMode()
      this._sendRemainTick(1)
    }
  }

  /**
   * @function prevZone
   * @desc move focus to previous zone area
   * @example
   * this.$focus.prevZone()
   */
  prevZone () {
    if (this._appType === APP_TYPE.GADGET) {
      this.exitFocusMode()
      this._sendRemainTick(1)
      return
    }

    if (!this._zoneFocusMode && !this._componentFocusMode) {
      this.startFocusMode()
      this._sendRemainTick(0)
      return
    }

    this._setComponentFocusOff()

    if (this._currentZone === 3 && this._popupType === POPUP_TYPE.NONE) {
      this._$focusZoneEle.classList.remove('three')
      this._$focusZoneEle.classList.add('two')
      this._currentZone -= 1
      this.startFocusMode()
      this._sendRemainTick(0)
      // this._sendRemainTick(0)
    } else {
      this.exitFocusMode()
      this._sendRemainTick(1)
    }
  }

  /**
   * @function nextOrder
   * @desc move focus to next focusable component
   * @example
   * this.$focus.nextOrder()
   */
  nextOrder (tick = 0) {
    let newOrder = this._getClosestFocusableComponent(this._currentOrder + 1) // find closest focusable component

    this._setComponentFocusOff()
    this._currentOrder = (newOrder === -1) ? this._currentOrder : newOrder
    this._setComponentFocusOn(ROTATE_RIGHT)
    this._sendRemainTick(0)
  }

  /**
   * @function prevOrder
   * @desc move focus to previous focusable component
   * @example
   * this.$focus.prevOrder()
   */
  prevOrder (tick = 0) {
    let newOrder = this._getClosestFocusableComponent(this._currentOrder - 1, false) // find closest focusable component
    // newOrder = (!this._Loop && this._currentOrder === 0)
    this._setComponentFocusOff()
    this._currentOrder = (newOrder === -1) ? this._currentOrder : newOrder
    this._setComponentFocusOn(ROTATE_LEFT)
    this._sendRemainTick(0)
  }

  /**
   * @ignore
   * @function _getClosestFocusableComponent
   * @param order
   * @param isNext search direction
   * @return {*}
   * @desc get cloosest focusable component from order(first argument) in current scene
   */
  _getClosestFocusableComponent (order = this._currentOrder, isNext = true) {
    let sceneMap = this._getCurrentSceneMap()
    let scene = this._currentScene
    let n = 0

    if (!sceneMap && this._currentZone === 3) { // footer가 app.vue에 하나 존재하고 페이지에 존재하지 않는 경우 scene을 0으로 하여 footer의 focusable component를 검색
      scene = 0
      sceneMap = this._getSceneMap(this._currentZone, scene)
    }

    const incrementer = (isNext) ? 1 : -1 // prev검색 or next 검색
    const size = (sceneMap) ? sceneMap.size : 0

    if (!this._Loop && this._currentZone !== 3) {
      order = (order < 0) ? this._currentOrder : (order >= size) ? this._currentOrder : order // size 넘어서는 경우 보정
    } else {
      order = (order < 0) ? size - 1 : (order >= size) ? 0 : order // size 넘어서는 경우 보정
    }

    while (n++ < size) {
      if (this._isTargetAvailable(scene, order)) {
        return order
      }
      order = order + incrementer
      order = (order < 0) ? size : (order > size) ? 0 : order
    }

    return -1
  }

  /**
   * @ignore
   * @function _isTargetAvailable
   * @param scene
   * @param order
   * @return {boolean}
   * @desc check target able/disable
   */
  _isTargetAvailable (scene, order) {
    const sceneMap = this._getSceneMap(this._currentZone, scene)
    const targetComponent = (sceneMap) ? sceneMap.get(order) : null

    if (targetComponent) {
      let $target = targetComponent.el
      return !($target.disabled || $target.classList.contains('disabled') || $target.classList.contains('disable'))
    }

    return false
  }

  /**
   * @ignore
   * @function _getCurrentTarget
   * @return {null}
   * @desc get current focused component from focus map
   * @private
   */
  _getCurrentTarget () {
    let sceneMap = this._getCurrentSceneMap()

    if (sceneMap && sceneMap.size > 0) {
      return sceneMap.get(this._currentOrder)
    }

    if (this._currentZone === 3) { // zone 3이면서 해당 scene에 별도의 footer가 없는 경우
      sceneMap = this._getSceneMap(this._currentZone, 0)
      return sceneMap.get(this._currentOrder)
    }

    return null
  }

  /**
   * @ignore
   * @function _setComponentFocusOn
   * @private
   * @desc add focus class to current focusable component and emit 'focusin' event
   * @param direction
   */
  _setComponentFocusOn (direction = ROTATE_RIGHT) {
    let target = this._getCurrentTarget()
    if (target) {
      target.el.classList.add('obg-focus')
      if (target.vnode && target.vnode.componentInstance) {
        target.vnode.componentInstance.$emit('focusin', {'target': target.el, 'direction': direction})
      } else {
        const focusInEvent = new CustomEvent('focusin', {'target': target.el, 'direction': direction})
        target.el.dispatchEvent(focusInEvent)
      }
    }
  }

  /**
   * @ignore
   * @function _setComponentFocusOff
   * @private
   * @desc remove focus class to current focusable component and emit 'focusout' event
   */
  _setComponentFocusOff () {
    let target = this._getCurrentTarget()
    if (target) {
      target.el.classList.remove('obg-focus')
      if (target.vnode && target.vnode.componentInstance) {
        target.vnode.componentInstance.$emit('focusout', {'target': target.el})
      } else {
        const focusOutEvent = new CustomEvent('focusout', {'target': target.el})
        target.el.dispatchEvent(focusOutEvent)
      }
    }
  }

  /**
   * @ignore
   * @function _getZoneMap
   * @param zone
   * @return {V}
   * @private
   * @desc returns the map that specified zone
   */
  _getZoneMap (zone) {
    let zoneMap = this._focusMap.get(zone)
    if (!zoneMap) {
      zoneMap = new Map()
      this._focusMap.set(zone, zoneMap)
    }
    return zoneMap
  }

  /**
   * @ignore
   * @function _getSceneMap
   * @param zone
   * @param scene
   * @private
   * @desc returns the map that specified zone and scene
   */
  _getSceneMap (zone, scene) {
    let zoneMap = this._getZoneMap(zone)
    let sceneMap = zoneMap.get(scene)
    if (!sceneMap) {
      sceneMap = new Map()
      zoneMap.set(scene, sceneMap)
    }
    return sceneMap
  }

  /**
   * @ignore
   * @function _removeSceneMap
   * @param zone
   * @param scene
   * @private
   */
  _removeSceneMap (zone, scene) {
    let zoneMap = this._getZoneMap(zone)
    let sceneMap = zoneMap.get(scene)
    if (sceneMap) zoneMap.set(scene, new Map())
    return sceneMap
  }

  /**
   * @ignore
   * @function _getCurrentSceneMap
   * @private
   * @desc returns the map that current zone and scene
   */
  _getCurrentSceneMap () {
    const zoneMap = this._focusMap.get(this._currentZone)
    return (zoneMap) ? zoneMap.get(this._currentScene) : null
  }

  /**
   * @ignore
   * @function _addComponent
   * @param el
   * @param {number} [scene=0]
   * @param {number} [zone=2]
   * @param {number} [order]
   * @param {object} [vnode]
   * @private
   * @desc add component to focus map when mounted
   * if scene,zone and order is duplicated skip it
   */
  _addComponent (el, {scene = 0, zone = 2, order, isFocus = false}, vnode) {
    const sceneMap = this._getSceneMap(zone, scene)
    if (typeof order === 'undefined') { // directive에서 order를 지정하지 않은 경우 순차적으로 order 부여 - keep-alive가 아닌 경우
      order = sceneMap.size
    }
    if (sceneMap.get(order)) {
      sceneMap.set(order, {el: el, vnode: vnode, isFocus: isFocus})
      console.log('[ObigoUI:error] Focus order is duplicated [ scene : ' + scene + ' / order : ' + order + '] - overwrite')
      return
    } else {
      sceneMap.set(order, {el: el, vnode: vnode, isFocus: isFocus})
    }
  }

  /**
   * @ignore
   * @function _removeComponent
   * @param {dom} el
   * @param zone
   * @param scene
   * @param order
   * @private
   * @desc remove component from focus map
   */
  _removeComponent (el, {zone = 2, scene = 0, order}) {
    const sceneMap = this._getSceneMap(zone, scene)
    if (typeof order === 'undefined') { // directive에서 order를 지정하지 않은 경우 뒤에서부터 순차적으로 삭제
      order = sceneMap.size - 1
    }
    sceneMap.delete(order)
  }

  _sendRemainTick (tick) {
    console.log('notProcessedCount : ' + tick)
    if (window.hardkeyEventObj) window.hardkeyEventObj.notProcessedCount(this._hardkeyCode, this._hardkeyMode, tick)
  }

  /**
   * @function setScene
   * @param {number} scene
   * @desc set scene
   * @example
   * this.$focus.setScene(0)
   */
  setScene (scene) {
    this._setZoneFocusOff()
    this._setComponentFocusOff()
    // this._zoneFocusMode = false
    // this._componentFocusMode = false
    this._currentZone = 2
    this._currentOrder = 0
    this._currentScene = scene
  }

  /**
   * @function setFocusPosition
   * @param {number} [scene=0]
   * @param {number} [order=0]
   * @param {number} [zone=0]
   * @desc set Focus position
   * @example
   * this.$focus.setFocusPosition({scene: 0, order: 0, zone: 2})
   */
  setFocusPosition ({scene = 0, order = 0, zone = 2}) {
    this._setZoneFocusOff()
    this._setComponentFocusOff()
    this._zoneFocusMode = false
    this._componentFocusMode = false
    this._currentOrder = order
    this._currentZone = zone
    this._currentScene = scene
  }

  /**
   * @function getCurrentPosition
   * @return {{order: (number), zone: (number), scene: (number)}}
   * @example
   * const obj = this.$focus.getCurrentPosition()
   * if (obj.zone === 2) console.log('focus position is zone 2')
   */
  getCurrentPosition () {
    return {
      'order': this._currentOrder,
      'zone': this._currentZone,
      'scene': this._currentScene
    }
  }

  /**
   * @function isFocusOn
   * @return {boolean}
   * @example
   * const isFocusMode = this.$focus.isFocusOn()
   */
  isFocusOn () {
    return this._zoneFocusMode && this._componentFocusMode
  }

  /**
   * @function setFocusOnByElement
   * @param {dom} el
   * @return {number}
   * @desc set focus on by element in zone2
   * @example
   * this.$focus.setFocusOnByElement(document.getElementById('sample'))
   */
  setFocusOnByElement (el) {
    this.exitFocusMode()
    let sceneMap = this._getSceneMap(2, this._currentScene)
    let size = sceneMap.size
    let newOrder = -1

    for (let i = 0; i < size; i++) {
      const item = sceneMap.get(i)
      if (item.el === el) {
        newOrder = i
        break
      }
    }

    if (newOrder > -1) {
      this._currentZone = 2
      this._currentOrder = newOrder
      // this.startFocusMode(true, newOrder)
      this._zoneFocusMode = true
      this._componentFocusMode = true
      this._setZoneFocusOn()
      this._setComponentFocusOn()
      window.addEventListener('click', this._onBodyClickListener)
    }

    return newOrder
  }

  /**
   * @function setOptions
   * @param {Object} [options]
   * @example
   * this.$focus.setOptions({loop:true|false})
   */
  setOptions ({loop}) {
    this._Loop = loop
  }

  /**
   * @function storeLastFocusPosition
   * @param key
   * @param value
   * @example
   * this.$focus.storeLastFocusPosition({name:'list-page', 10})
   */
  storeLastFocusPosition (key, value) {
    this._lastFocusMap.set(key, value)
  }

  /**
   * @function loadLastFocusPosition
   * @param key
   * @return {V} order
   * @example
   * this.$focus.startFocusMode(true, this.$focus.loadLastFocusPosition('list-page'))
   */
  loadLastFocusPosition (key) {
    return this._lastFocusMap.get(key)
  }
}

export var focusInstance = new Focus()

export function install (_Vue) {
  focusInstance._bind()
  _Vue.prototype.$focus = focusInstance
  return focusInstance
}
