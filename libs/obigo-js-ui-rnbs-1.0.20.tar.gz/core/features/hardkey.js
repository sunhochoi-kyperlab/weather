
let code = {
  HARDKEY_TYPE_NONE: 1000, // unknown hardkey type
  HARDKEY_BUTTON_HOME: 1001, // home hardkey
  HARDKEY_BUTTON_BACK: 1002, // back hardkey
  HARDKEY_ROTARY_ROTATE: 2001, // rotary rotate hardkey
  HARDKEY_ROTARY_ENTER: 2002, // rotaty enter hardkey
  HARDKEY_ROTARY_LEFT: 2003, // rotary left hardkey
  HARDKEY_ROTARY_RIGHT: 2004, // rotary right hardkey
  HARDKEY_ROTARY_UP: 2005, // rotary up hardkey
  HARDKEY_ROTARY_DOWN: 2006 // rotary down hardkey
}

let mode = {
  HARDKEY_MODE_NONE: 0, // unknown hardkey mode
  HARDKEY_MODE_PRESS: 1, // hardkey press
  HARDKEY_MODE_LONG_PRESS: 2, // hardkey long press
  HARDKEY_MODE_RELEASE: 3, // hardkey release
  HARDKEY_MODE_LEFT: 4, // rotary hardkey rotate left  81 q
  HARDKEY_MODE_RIGHT: 5 // rotary hardkey rotate right 69 e
}

function getKeyCodes () {
  if (!window.applicationFramework) {
    code = {
      HARDKEY_TYPE_NONE: 1000, // unknown hardkey type
      HARDKEY_BUTTON_HOME: 104, // home hardkey
      HARDKEY_BUTTON_BACK: 98, // back hardkey
      HARDKEY_ROTARY_ROTATE: 113, // rotary rotate hardkey  q 113
      HARDKEY_ROTARY_ENTER: 114, // rotaty enter hardkey r 114
      HARDKEY_ROTARY_LEFT: 97, // rotary left hardkey a
      HARDKEY_ROTARY_RIGHT: 100, // rotary right hardkey d
      HARDKEY_ROTARY_UP: 119, // rotary up hardkey w
      HARDKEY_ROTARY_DOWN: 115 // rotary down hardkey s
    }
  }
  return {
    code: code,
    mode: mode
  }
}

export const hardkeyCode = getKeyCodes()

/**
 * @module hardkey
 * @desc hardkey function
 *
 * @example
 * let codes = this.$hardkey.getCodes()
 * this.$hardkey.addEventListener(codes.code.HARDKEY_BUTTON_HOME, handler)
 * this.$hardkey.removeHardkeyListener(codes.code.HARDKEY_BUTTON_HOME)
 */
import appManager from './appManager'
import eventbus from './events'

class Hardkey {
  constructor () {
    this.appManager = appManager
    this._bind()
    this._hardKeyListener = []
  }

  _bind () {
    if (this.appManager) {
      window.addEventListener('hardkey', this._handleEvent.bind(this))
    } else {
      document.addEventListener('keypress', this._handleEvent.bind(this))
    }
  }

  _handleEvent (event) {
    const code = event.hardkeyType !== undefined ? event.hardkeyType : event.key.charCodeAt(0)
    const mode = event.hardkeyMode !== undefined ? event.hardkeyMode : (event.ctrlKey ? hardkeyCode.mode.HARDKEY_MODE_LEFT : hardkeyCode.mode.HARDKEY_MODE_RIGHT)
    const tick = event.hardkeyTick

    window.hardkeyEventObj = (event.hardkeyType) ? event : {'notProcessedCount': function () {}}
    window.hardkeyEventObj.code = code
    window.hardkeyEventObj.mode = mode

    const arr = this._findKeyCode(code)
    arr.forEach((item) => {
      item.cb({code, mode, tick})
    })

    this._emitArrowKeyEvent(event)
  }

  /**
   * @function addHardkeyListener
   * @param {number} type hardkey type code
   * @param {function} cb handler
   * @summary add hardkey listener
   */
  addHardkeyListener (type, cb) {
    this._hardKeyListener.push({
      type: type,
      cb: cb
    })
  }

  /**
   * @function removeHardkeyListener
   * @param {number} type hardkey type code
   * @summary remove hardkey listener
   */
  removeHardkeyListener (type, cb) {
    this._hardKeyListener = this._hardKeyListener.filter((obj) => {
      return !(obj.cb === cb && obj.type === type)
    })
  }

  _findKeyCode (val) {
    return this._hardKeyListener.filter((obj) => {
      return obj.type === val
    })
  }

  /**
   * @function getCodes
   * @return {{code, mode}|*} hardkey type code and hardkey mode
   * @summary get hardkey codes
   */
  getCodes () {
    return hardkeyCode
  }

  /**
   * @function sendRemainTick
   * @param tick
   * @desc send remainTick to native
   */
  sendRemainTick (tick = 1) {
    window.hardkeyEventObj.notProcessedCount(window.hardkeyEventObj.code, window.hardkeyEventObj.mode, tick)
  }

  _emitArrowKeyEvent (event) {
    switch (event.hardkeyType) {
      case hardkeyCode.code.HARDKEY_ROTARY_LEFT:
        eventbus.$emit('csw:left', event)
        break
      case hardkeyCode.code.HARDKEY_ROTARY_RIGHT:
        eventbus.$emit('csw:right', event)
        break
      case hardkeyCode.code.HARDKEY_ROTARY_UP:
        eventbus.$emit('csw:up', event)
        break
      case hardkeyCode.code.HARDKEY_ROTARY_DOWN:
        eventbus.$emit('csw:down', event)
        break
      default:
        break
    }
  }
}

export var hardkeyInstance = new Hardkey()

