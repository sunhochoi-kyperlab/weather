export default function (router) {
  router.isBack = false
  router._go = router.go

  router._push = router.push

  router.go = function (n) {
    router._go(n)
    if (n < 0) {
      router.isBack = true
    }
  }

  router.push = function (loc, onComplete, onAbort) {
    router._push(loc, onComplete, onAbort)
    router.isBack = false
  }

  return router
}
