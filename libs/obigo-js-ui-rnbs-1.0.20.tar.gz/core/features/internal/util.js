/**
 * @module util
 * @desc utility functions.
 * @example 
 * var appFrm = window.applicationFramework
 * var util = appFrm.util
 */

class util{

  /**
   * @function getOSVersion 
   * @summary return OS version
   * @return {string} - OS version
   * @example
   * var nowLang = applicationFramework.util.getOSVersion()
   *
   */
  getOSVersion () {
  }

  /**
   * @function getLanguage
   * @summary to get current language of widgets
   * @return {string} lang - widgets language
   * @example
   * var nowLang = applicationFramework.util.getLanguage()
   *
   */
  getLanguage () {
  }

  /**
   * @function getAmbientColor
   * @summary to get ambient colors
   * @return {string} ambientColor - ambient color
   * @example
   * var nowColor = applicationFramework.util.getAmbientColor()
   *
   */
  getAmbientColor () {
  }

  /**
   * @function getDeviceModel 
   * @summary to get device model name
   * @return {string} modelName - model name
   * @example
   * var nowColor = applicationFramework.util.getDeviceModel()
   *
   */
  getAmbientColor () {
  }
}

