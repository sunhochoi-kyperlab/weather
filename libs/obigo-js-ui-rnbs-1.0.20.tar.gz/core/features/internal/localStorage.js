
/**
 * @module localStorage
 * @desc local storage module.
 * <br/>use browser native local storage.
 * <br/>you can use built-in localStorage in SDK like Chrome, FF, IE etc.
 */
class localStorage {
}
