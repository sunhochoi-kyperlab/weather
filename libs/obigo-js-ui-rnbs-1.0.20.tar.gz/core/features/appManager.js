function getAppManager () {
  if (window.applicationFramework) {
    return window.applicationFramework.applicationManager.getOwnerApplication(window.document)
  }
}

export default getAppManager()
