import {triggerBodyClickEvent} from '../utils/event'

const parentMixin = {
  mounted () {
    if (this.value >= 0) {
      this.currentIndex = this.value
      this.previousIndex = this.value
    } else {
      this.currentIndex = 0
      this.previousIndex = 0
    }
    this.updateIndex()
  },
  methods: {
    updateIndex () {
      if (!this.$children) return
      this.number = this.$children.length
      let children = this.$children
      for (let i = 0; i < children.length; i++) {
        children[i].currentIndex = i
        if (children[i].currentSelected) {
          this.currentIndex = i
        }
      }
    }
  },
  props: {
    value: Number
  },
  watch: {
    currentIndex (val, oldVal) {
      oldVal > -1 && this.$children[oldVal] && (this.$children[oldVal].currentSelected = false)
      val > -1 && (this.$children[val].currentSelected = true)
      this.previousIndex = (!oldVal) ? -1 : oldVal
      this.$emit('input', val)
    },
    index (val) {
      this.currentIndex = val
    },
    value (val) {
      this.index = val
    }
  },
  data () {
    return {
      index: -1,
      previousIndex: -1,
      currentIndex: this.index,
      number: 0
    }
  }
}

const childMixin = {
  props: {
    selected: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  mounted () {
    this.$parent.updateIndex()
  },
  beforeDestroy () {
    const $parent = this.$parent
    this.$nextTick(() => {
      $parent.updateIndex()
    })
  },
  methods: {
    onItemClick (hasLink) {
      if (this.currentSelected || this.disabled) return

      this.currentSelected = true
      this.$parent.currentIndex = this.currentIndex
      this.$emit('on-item-click', this.currentIndex)
      triggerBodyClickEvent()
    }
  },
  watch: {
    currentSelected (val) {
      if (val) {
        this.$parent.index = this.currentIndex
      }
    },
    selected (val) {
      this.currentSelected = val
    }
  },
  data () {
    return {
      currentIndex: -1,
      currentSelected: this.selected
    }
  }
}

export {
  parentMixin,
  childMixin
}
