<template>
  <div
    class="obg-slider"
    :class="[mode + '-mode', { 'obg-slider-disabled': disabled }]"
    :style="{ 'width': sliderWidth + 'px'}"
  >
    <slot name="start"></slot>
    <div class="obg-slider-content" ref="content" @mousedown.prevent="onClickBar">
      <div class="obg-slider-runway" :style="{ 'border-top-width': barHeight + 'px' }" ></div>
      <div class="obg-slider-buffer" :style="{ width: bufferPercent + '%', height: barHeight + 'px' }" ></div>
      <div class="obg-slider-progress" :style="{ width: progress + '%', height: barHeight + 'px' }" ></div>
      <div
        class="obg-slider-thumb"
        :class="{'animate-scale': thumbScale, 'start': (progress === 0), 'end': (progress === 100)}"
        ref="thumb"
        :style="{ left: progress + '%' }"
      >
        <span v-if="thumbLabel" class="obg-slider-current-value">{{progress}}</span>
      </div>
    </div>
    <slot name="end"></slot>
  </div>
</template>

<script type="text/babel">
  /**
   * @class slider
   * @classdesc components/slider
   * @param {slot} [slot='start']
   * @param {slot} [slot='end']
   * @param {number} [min=0]
   * @param {number} [max=100]
   * @param {number} [step=1]
   * @param {number} [value=0]
   * @param {number} [barHeight=5]
   * @param {number} [sliderWidth=500]
   * @param {boolean} [draggable=true]
   * @param {boolean} [disabled=false]
   * @param {event} [input]
   *
   * @example
   * <obg-slider
   *  class="slider"
   *  v-model="model"
   *  :min="0"
   *  :max="100" @input="onInput"
   *  ></obg-slider>
   */
  import draggable from '../../features/draggable'
  export default {
    name: 'obg-slider',
    props: {
      min: {
        type: Number,
        default: 0
      },
      max: {
        type: Number,
        default: 100
      },
      step: {
        type: Number,
        default: 1
      },
      disabled: {
        type: Boolean,
        default: false
      },
      value: {
        type: Number
      },
      barHeight: {
        type: Number,
        default: 2
      },
      draggable: {
        type: Boolean,
        default: true
      },
      focus: {
        type: Boolean,
        defalut: false
      },
      sliderWidth: {
        type: Number,
        default: 454
      },
      thumbLabel: {
        type: Boolean,
        default: false
      },
      thumbScale: {
        type: Boolean,
        default: true
      },
      mode: {
        type: String,
        default: 'slider'
      },
      buffer: {
        type: Number,
        default: 0
      }
    },
    computed: {
      progress () {
        const value = this.value
        if (typeof value === 'undefined' || value === null || value === 0) return 0
        if (this.value >= this.max) {
          return 100
        } else if (this.value <= this.min) {
          return 0
        }
        return Math.floor((value - this.min) / (this.max - this.min) * 100)
      },
      bufferPercent () {
        const buffer = this.buffer
        if (typeof buffer === 'undefined' || buffer === null || buffer === 0) return 0
        if (this.buffer >= this.max) {
          return 100
        } else if (this.buffer <= this.min) {
          return 0
        }
        return Math.floor((buffer - this.min) / (this.max - this.min) * 100)
      }
    },
    watch: {
      focus (isFocus) {
        if (isFocus) {
          this.$refs.thumb.classList.add('focus')
        } else {
          this.$refs.thumb.classList.remove('focus')
        }
      },
      max (val) {
        this.stepCount = Math.ceil((this.max - this.min) / this.step)
      },
      min (val) {
        this.stepCount = Math.ceil((this.max - this.min) / this.step)
      },
      step (val) {
        this.stepCount = Math.ceil((this.max - this.min) / this.step)
      }
    },
    mounted () {
      const thumb = this.$refs.thumb
      const content = this.$refs.content
      this.stepCount = Math.ceil((this.max - this.min) / this.step)
      const getThumbPosition = () => {
        const contentBox = content.getBoundingClientRect()
        const thumbBox = thumb.getBoundingClientRect()
        return {
          left: thumbBox.left - contentBox.left,
          top: thumbBox.top - contentBox.top,
          contentBox: contentBox,
          thumbBox: thumbBox
        }
      }
      if (this.draggable) {
        let dragState = {}
        draggable(thumb, {
          start: (event) => {
            if (this.disabled) return
            const position = getThumbPosition()
            const pageX = event.touches ? event.touches[0].pageX : event.pageX
            dragState = {
              thumbStartLeft: position.left,
              thumbStartTop: position.top,
              eventStartX: pageX
            }
            this.$emit('dragstart')
          },
          drag: (event) => {
            const pageX = event.touches ? event.touches[0].pageX : event.pageX
            const distance = Math.abs(pageX - dragState.eventStartX)
            if (this.disabled || distance < 10) return
            const contentBox = content.getBoundingClientRect()
            const thumbWidthDividerVal = this.mode === 'slider' ? 5 : 2
            let thumbFactor = (this.$refs.thumb.getBoundingClientRect().width / thumbWidthDividerVal) / contentBox.width
            const deltaX = pageX - contentBox.left - dragState.thumbStartLeft
            const newPosition = (dragState.thumbStartLeft + deltaX) - (dragState.thumbStartLeft + deltaX) % (contentBox.width / this.stepCount)
            thumbFactor = Number((thumbFactor / this.step).toFixed(1))
            let newProgress = newPosition / contentBox.width - thumbFactor

            if (newProgress < 0) {
              newProgress = 0
            } else if (newProgress > 1) {
              newProgress = 1
            }
            this.$emit('input', Math.round(this.min + newProgress * (this.max - this.min)))
          },
          end: () => {
            if (this.disabled) return
            this.$emit('input', this.value)
            dragState = {}
            this.$emit('dragend')
          }
        })
      }
    },
    methods: {
      onClickBar (event) {
        if (this.draggable && this.mode === 'slider') {
          const contentBox = this.$refs.content.getBoundingClientRect()
          const deltaX = event.pageX - contentBox.left
          let newProgress = Math.floor(this.max * deltaX / contentBox.width)
          if (newProgress < this.min) {
            newProgress = this.min
          } else if (newProgress > this.max) {
            newProgress = this.max
          }
          this.$emit('input', newProgress)
          event.stopPropagation()
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  /*
    @import '../../styles/common/colors.variables.scss';
    */

  @keyframes thumb-scale {
    0% {
      transform: scale(0.7)
    }
    100% {
      transform: scale(1)
    }
  }
</style>
