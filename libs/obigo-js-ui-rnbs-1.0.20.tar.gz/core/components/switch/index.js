import onOffSwitch from './switch'
export default onOffSwitch
