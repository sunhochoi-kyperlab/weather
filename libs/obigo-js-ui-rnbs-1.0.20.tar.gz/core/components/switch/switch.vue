<template>
  <div class='container'
    @touchstart='containerStart'
    @click.stop
    :class='{disabled: disabled, active: active}'
    ref='container' 
  >
    <input type="checkbox" @click.stop  :disabled="disabled" :value='val' v-model="model">
    <div class="outer" @click.stop >
      <div class='area' @click.stop >
        <div class='indicator'
          @touchstart='indicatorStart'
          @click.stop
          ref='indicator' 
        >{{indicatorText}}</div>
      </div>
    </div>
  </div>
</template>

<script>
/**
 * @class switch
 * @classdesc components/switch
 * @param {boolean} [v-model=true] required
 * @param {boolean} [disabled=false]
 *
 *
 * @example
 * <obg-switch v-model='val' ></obg-switch>
 */
const isTouch = window.ontouchstart !== undefined
const EVT_START = isTouch ? 'touchstart' : 'mousedown'
const EVT_END = isTouch ? 'touchend' : 'mouseup'
const EVT_MOVE = isTouch ? 'touchmove' : 'mousemove'
const EVT_LEAVE = isTouch ? 'touchleave' : 'mouseleave'
const EVT_CANCEL = isTouch ? 'touchcancel' : 'mousecancel'
export default {
  name: 'obg-switch',
  methods: {
    clickHandler (e) {
      // for focus click
      if (this.disabled) {
        return
      }
      this.model = !this.model
      this.updateIndicatorX()
    },
    containerStart (e) {
      e.stopPropagation()
      e = e.touches ? e.touches[0] : e
      if (this.disabled) {
        return
      }
      this.isContainerDown = true
      console.log('constart')
      this.active = true
      this.$el.addEventListener(EVT_END, this.containerEnd, false)
      this.$el.addEventListener(EVT_CANCEL, this.containerCancel, false)
      this.$el.addEventListener(EVT_LEAVE, this.containerCancel, false)
      this.$el.removeEventListener('click', this.clickHandler)
    },
    containerCancel (e) {
      e = e.touches ? e.touches[0] : e
      console.log('concancel')
      this.active = false
      this.$el.removeEventListener(EVT_END, this.containerEnd)
      this.$el.removeEventListener(EVT_CANCEL, this.containerCancel)
      this.$el.removeEventListener(EVT_LEAVE, this.containerCancel)
      this.$el.addEventListener('click', this.clickHandler, false)
    },
    containerEnd (e) {
      console.log('endend')
      e.stopPropagation()
      e = e.touches ? e.touches[0] : e
      this.active = false
      this.model = !this.model
      this.updateIndicatorX()

      this.$el.removeEventListener(EVT_END, this.containerEnd)
      this.$el.removeEventListener(EVT_CANCEL, this.containerCancel)
      this.$el.removeEventListener(EVT_LEAVE, this.containerCancel)
      setTimeout(() => {
        this.$el.addEventListener('click', this.clickHandler, false)
      }, 0)
    },
    indicatorStart (e) {
      e.stopPropagation()
      e = e.touches ? e.touches[0] : e
      if (this.disabled) {
        return
      }
      console.log('indi start')
      this.isIndicatorMove = false
      this.active = true
      this.beforeX = e.clientX
      this.addBodyEvent()
      this.indicator.addEventListener(EVT_END, this.indicatorEnd, false)
      this.indicator.addEventListener(EVT_MOVE, this.indicatorMove, false)
      this.$el.removeEventListener('click', this.clickHandler)
    },
    indicatorEnd (e) {
      e.stopPropagation()
      e = e.touches ? e.touches[0] : e
      console.log('indi end')
      this.active = false

      if (this.isIndicatorMove === false) {
        this.model = !this.model
        this.updateIndicatorX()
      } else {
        if (this.indicatorX < (this.max + this.min) / 2) {
          this.indicatorX = this.min
          this.model = false
        } else {
          this.indicatorX = this.max
          this.model = true
        }
        this.indicator.style.transform = 'translateX(' + this.indicatorX + 'px)'
        this.indicator.style.WebkitTransform = 'translateX(' + this.indicatorX + 'px)'
      }

      this.indicator.removeEventListener(EVT_START, this.indicatorEnd)
      this.indicator.removeEventListener(EVT_MOVE, this.indicatorMove)

      setTimeout(() => {
        // setTimeout 하지 않으면 mouseup이벤트 이후 바로 click이벤트가 발생하여
        // 해당 이벤트 처리기가 수행됨
        this.$el.addEventListener('click', this.clickHandler, false)
      }, 0)
      this.removeBodyEvent()
    },
    indicatorMove (e) {
      e.stopPropagation()
      e = e.touches ? e.touches[0] : e
      var diff = e.clientX - this.beforeX
      this.isIndicatorMove = true
      this.indicatorX += diff
      this.indicatorX = Math.max(Math.min(this.indicatorX, this.max), this.min)
      this.indicator.style.transform = 'translateX(' + this.indicatorX + 'px)'
      this.indicator.style.WebkitTransform = 'translateX(' + this.indicatorX + 'px)'
      this.beforeX = e.clientX
    },
    addBodyEvent () {
      document.body.addEventListener(EVT_END, this.indicatorEnd, false)
      document.body.addEventListener(EVT_LEAVE, this.indicatorEnd, false)
      document.body.addEventListener(EVT_MOVE, this.indicatorMove, false)
      document.body.addEventListener(EVT_CANCEL, this.indicatorEnd, false)
    },
    removeBodyEvent () {
      document.body.removeEventListener(EVT_END, this.indicatorEnd)
      document.body.removeEventListener(EVT_LEAVE, this.indicatorEnd)
      document.body.removeEventListener(EVT_MOVE, this.indicatorMove)
      document.body.removeEventListener(EVT_CANCEL, this.indicatorEnd)
    },
    updateIndicatorX () {
      this.$nextTick(() => {
        if (this.model) {
          this.indicatorX = 55
          this.indicatorText = 'ON'
        } else {
          this.indicatorX = 5
          this.indicatorText = 'OFF'
        }
        this.indicator.style.transform = 'translateX(' + this.indicatorX + 'px)'
        this.indicator.style.WebkitTransform = 'translateX(' + this.indicatorX + 'px)'
      })
    }
    /*
    onListItemClick () {
      if (this.$parent.$el.classList.contains('obg-list-item')) {
        this.clickHandler()
      }
    }
    */

  },
  computed: {
    model: {
      get () {
        return this.value
      },
      set (value) {
        this.$emit('input', value)
      }
    }
  },
  updated () {
    this.updateIndicatorX()
  },
  mounted () {
    this.indicator = this.$el.querySelector('.indicator')
    this.checkbox = this.$el.querySelector('input')
    this.$el.addEventListener('click', this.clickHandler, false)
    this.updateIndicatorX()
    this.min = 4
    this.max = 53
    this.indicatorX = 4
    // this.$parent.$on('click', this.onListItemClick)
    this.$refs.container.addEventListener(EVT_START, this.containerStart)
    this.$refs.indicator.addEventListener(EVT_START, this.indicatorStart)
  },
  beforeDestoryed () {
    this.$refs.container.removeEventListener(EVT_START, this.containerStart)
    this.$refs.indicator.removeEventListener(EVT_START, this.indicatorStart)
  },
  data () {
    return {
      indicatorText: 'ON',
      active: false
    }
  },
  props: {
    value: {
      required: true
    },
    val: {
    },
    disabled: Boolean
  }
}
</script>

<style lang="scss" scoped >

</style>
