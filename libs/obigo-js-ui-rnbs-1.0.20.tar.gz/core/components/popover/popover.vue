<template>
  <div
    class="obg-popover animate-scale"
    @click.stop
    :style="transformCSS"
  >
    <slot></slot>
  </div>
</template>

<script>
  /**
   * @class popover
   * @classdesc components/popover
   * @param {string} [anchor='bottom left'] top | center | bottom + left | middle | right
   * @param {string} [self='top left'] top | center | bottom + left | middle | right
   * @param {string} [maxHeight]
   * @param {boolean} [disable]
   * @param {boolean} [touchPosition]
   * @param {boolean} [anchorClick=true]
   * @param {array} [offset]
   * @param {slot} [slot]
   *
   * @example
   * <obg-popover
   *  :anchor="bottom left"
   *  :self="top left"
   * >
   *   <div v-for="n in 5">
   *     <div class="item-content">
   *       {{n}}
   *     </div>
   *   </div>
   *  </obg-popover>
   */
  import * as validator from './popover'

  export default {
    props: {
      anchor: {
        type: String,
        default: 'bottom left',
        validator: validator.positionValidator
      },
      self: {
        type: String,
        default: 'top left',
        validator: validator.positionValidator
      },
      maxHeight: String,
      touchPosition: Boolean,
      anchorClick: {
        /*
         for handling anchor outside of Popover
         example: context menu component
         */
        type: Boolean,
        default: true
      },
      offset: {
        type: Array,
        validator: validator.offsetValidator
      },
      disable: Boolean
    },
    data () {
      return {
        opened: false,
        progress: false
      }
    },
    computed: {
      transformCSS () {
        return this.getTransformProperties({selfOrigin: this.selfOrigin})
      },
      anchorOrigin () {
        return this.parsePosition(this.anchor)
      },
      selfOrigin () {
        return this.parsePosition(this.self)
      }
    },
    mounted () {
      this.$nextTick(() => {
        this.anchorEl = this.$el.parentNode
        this.anchorEl.removeChild(this.$el)
        this.anchorEl = (this.anchorEl.tagName === 'BUTTON') ? this.anchorEl : this.anchorEl.parentNode // for obg-button
        if (this.anchorClick) {
          this.anchorEl.classList.add('cursor-pointer')
          this.anchorEl.addEventListener('click', this.toggle)
        }
      })
    },
    beforeDestroy () {
      if (this.anchorClick && this.anchorEl) {
        this.anchorEl.removeEventListener('click', this.toggle)
      }
      this.close()
    },
    methods: {
      toggle (event) {
        // if (event.srcElement === event.currentTarget) return
        if (this.opened) {
          this.close()
        } else {
          this.open(event)
        }
      },
      open (event) {
        if (this.disable || this.opened) {
          return
        }
        if (event) {
          event.stopPropagation()
          event.preventDefault()
        }

        this.opened = true
        document.body.click() // close other Popovers
        document.body.appendChild(this.$el)
        document.addEventListener('click', this.close)
        this.$el.addEventListener('click', this.close)
        this.$nextTick(() => {
          this.__updatePosition(event)
          this.$emit('open')
        })
      },
      close (fn) {
        if (!this.opened || this.progress) {
          return
        }
        document.removeEventListener('click', this.close)
        this.progress = true

        /*
         Using setTimeout to allow
         v-models to take effect
         */
        this.$nextTick(() => {
          this.opened = false
          this.progress = false
          // document.body.removeChild(this.$el)
          let $popover = document.body.getElementsByClassName('obg-popover animate-scale')
          if ($popover.length > 0) document.body.removeChild($popover[0])
          this.$emit('close')
          if (typeof fn === 'function') {
            fn()
          }
        })
      },
      __updatePosition (event) {
        this.setPosition({
          event,
          el: this.$el,
          offset: this.offset,
          anchorEl: this.anchorEl,
          anchorOrigin: this.anchorOrigin,
          selfOrigin: this.selfOrigin,
          maxHeight: this.maxHeight,
          anchorClick: this.anchorClick,
          touchPosition: this.touchPosition
        })
      },
      parsePosition (pos) {
        let parts = pos.split(' ')
        return {vertical: parts[0], horizontal: parts[1]}
      },
      getTransformProperties ({selfOrigin}) {
        let vert = selfOrigin.vertical
        let horiz = selfOrigin.horizontal === 'middle' ? 'center' : selfOrigin.horizontal

        return {
          'transform-origin': vert + ' ' + horiz + ' 0px'
        }
      },
      setPosition ({el, anchorEl, anchorOrigin, selfOrigin, maxHeight, event, anchorClick, touchPosition, offset}) {
        let anchor

        if (event && (!anchorClick || touchPosition)) {
          const {top, left} = this.eventPosition(event)
          anchor = {top, left, width: 1, height: 1, right: left + 1, center: top, middle: left, bottom: top + 1}
        } else {
          anchor = this.getAnchorPosition(anchorEl, offset)
        }

        let target = this.getTargetPosition(el)
        let targetPosition = {
          top: anchor[anchorOrigin.vertical] - target[selfOrigin.vertical],
          left: anchor[anchorOrigin.horizontal] - target[selfOrigin.horizontal]
        }

        // targetPosition = applyAutoPositionIfNeeded(anchor, target, selfOrigin, anchorOrigin, targetPosition)

        el.style.top = Math.max(0, targetPosition.top) + 'px'
        el.style.left = Math.max(0, targetPosition.left) + 'px'
        el.style.maxHeight = this.maxHeight || window.innerHeight * 0.9 + 'px'
      },
      eventPosition (e) {
        let posx, posy

        if (e.clientX || e.clientY) {
          posx = e.clientX
          posy = e.clientY
        } else if (e.pageX || e.pageY) {
          posx = e.pageX - document.body.scrollLeft - document.documentElement.scrollLeft
          posy = e.pageY - document.body.scrollTop - document.documentElement.scrollTop
        }

        return {
          top: posy,
          left: posx
        }
      },
      getAnchorPosition (el, offset) {
        let {top, left, right, bottom} = el.getBoundingClientRect()
        let a = {
          top,
          left,
          width: el.offsetWidth,
          height: el.offsetHeight
        }

        if (offset) {
          a.top += offset[1]
          a.left += offset[0]
          if (bottom) {
            bottom += offset[1]
          }
          if (right) {
            right += offset[0]
          }
        }

        a.right = right || a.left + a.width
        a.bottom = bottom || a.top + a.height
        a.middle = a.left + ((a.right - a.left) / 2)
        a.center = a.top + ((a.bottom - a.top) / 2)

        return a
      },
      getTargetPosition (el) {
        return {
          top: 0,
          center: el.offsetHeight / 2,
          bottom: el.offsetHeight,
          left: 0,
          middle: el.offsetWidth / 2,
          right: el.offsetWidth
        }
      }
    }
  }

</script>
<style lang="scss" scoped>
  .obg-popover{
    position: fixed;
    z-index: 200;
   /* overflow-y:auto;
    overflow-x:hidden;*/
  }
  .animate-scale {
    animation: popover-scale .2s;
  }

  @keyframes popover-scale {
    0% {
      opacity: 0;
      transform: scale(0.7)
    }
    100% {
      opacity: 1;
      transform: scale(1)
    }
  }

</style>
