<template>
  <div
    class="obg-playtime"
    :style="{ 'width': playtimeWidth + 'px'}"
    data-type="focus-control-able"
  >
    <div class="obg-playtime-label start">
      {{minTime}}
    </div>
    <obg-slider
      :min="min"
      :max="max"
      :barHeight="barHeight"
      :sliderWidth="sliderWidth"
      :focus="focus"
      :thumbLabel="false"
      :disabled="disabled"
      v-model="model"
      :buffer="buffer"
      ref="slider"
      @input="onInput"
      @mousedown.stop
      @mouseup.stop
      @dragstart="onDragStart"
      @dragend="onDragEnd"
    ></obg-slider>
    <div class="obg-playtime-label end">
      {{maxTime}}
    </div>
  </div>
</template>
<script type="text/babel">
  /**
   * @class playtime
   * @classdesc components/playtime
   * @param {number} [min=0]
   * @param {number} [max=100]
   * @param {number} [step=1]
   * @param {number} [value=0]
   * @param {number} [barHeight=5]
   * @param {number} [sliderWidth=500]
   * @param {number} [playtimeWidth=500]
   * @param {boolean} [draggable=true]
   * @param {boolean} [disabled=false]
   *
   * @example
   * <obg-playtime
   *  v-model="model"
   *  :min="0"
   *  :max="100" @input="onInput"
   *  ></obg-playtime>
   */
  import slider from '../slider'
  import Utils from '../../utils'
  import focusControlMixin from '../../mixins/focus-control'

  export default {
    name: 'obg-playtime',
    components: {
      'obg-slider': slider
    },
    mixins: [focusControlMixin],
    props: {
      min: {
        type: Number,
        default: 0
      },
      max: {
        type: Number,
        default: 100
      },
      step: {
        type: Number,
        default: 1
      },
      disabled: {
        type: Boolean,
        default: false
      },
      value: {
        type: Number,
        default: 0
      },
      barHeight: {
        type: Number
      },
      sliderWidth: {
        type: Number,
        default: 468
      },
      playtimeWidth: {
        type: Number,
        default: 800
      },
      buffer: {
        type: Number,
        default: 0
      }
    },
    computed: {
      minTime () {
        if (this.value === 0) {
          return Utils.time.secToTime(this.min)
        }
        return Utils.time.secToTime(this.value)
      }
    },
    watch: {
      value (val) {
        this.model = (val < this.max) ? val : this.max
        if (this.focus) this.$thumb.classList.add('obg-focus')
      },
      max (val) {
        this.maxTime = Utils.time.secToTime(val)
      }
    },
    data () {
      return {
        model: (this.value < this.min) ? this.min : this.value,
        focus: false,
        maxTime: Utils.time.secToTime(this.max)
      }
    },
    mounted () {
      this.$thumb = this.$el.querySelector('.obg-slider-thumb')
      this.$runway = this.$el.querySelector('.obg-slider-content')
      this.$on('focusin', this.onFocusIn)
      this.$on('focusout', this.onFocusOut)
    },
    methods: {
      valueDown () {
        this.model = this.model - this.step
        if (this.model < this.min) this.model = this.min
        this.$emit('input', this.model)
      },
      valueUp () {
        this.model = this.model + this.step
        if (this.model > this.max) this.model = this.max
        this.$emit('input', this.model)
      },
      onInput (val) {
        this.$emit('input', val)
      },
      onControlIn () {
        this.$el.classList.remove('obg-focus')
        this.$thumb.classList.add('obg-focus')
        this.onFocusIn()
      },
      onRotate ({mode}) {
        if (mode === this.hardkeyCodes.mode.HARDKEY_MODE_RIGHT) {
          this.valueUp()
        } else {
          this.valueDown()
        }
      },
      onRotateClick () {
        this.$el.classList.add('obg-focus')
        this.$thumb.classList.remove('obg-focus')
        this.onFocusOut()
      },
      exitFocusMode () {
        this.onFocusOut()
        this.exitFocusControlMode()
        this.$focus.exitFocusMode()
      },
      onFocusIn () {
        this.$el.addEventListener('mousedown', this.exitFocusMode)
        this.$el.addEventListener('touchstart', this.exitFocusMode)
        this.$runway.addEventListener('mousedown', this.exitFocusMode)
        this.$runway.addEventListener('touchstart', this.exitFocusMode)
      },
      onFocusOut () {
        this.$el.removeEventListener('mousedown', this.exitFocusMode)
        this.$el.removeEventListener('touchstart', this.exitFocusMode)
        this.$runway.removeEventListener('mousedown', this.exitFocusMode)
        this.$runway.removeEventListener('touchstart', this.exitFocusMode)
      },
      onDragStart (e) {
        this.$emit('dragstart', e)
      },
      onDragEnd (e) {
        this.$emit('dragend', e)
      }
    }
  }
</script>
<style lang="scss" scoped>
  /*
    @import '../../styles/common/colors.variables';
    */

</style>
