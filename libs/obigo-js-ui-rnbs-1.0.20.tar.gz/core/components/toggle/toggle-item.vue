<template>
  <button
    class="obg-toggle-item"
    :class="[{
      'obg-toggle-current': currentIndex === $parent.currentIndex,
      'disabled': disabled
    }]"
    @click.stop="onItemClick"
    @touchstart="onPressItem" @touchend="onReleaseItem"
    :style="{width: width + 'px'}"
  >
    <label class="obg-toggle-text"><slot></slot></label>
  </button>
</template>
<script>
/**
 * @class toggle-item
 * @classdesc components/toggle-item
 * @param {number} [width]
 * @param {boolean} [disabled=false]
 * @param {boolean} [selected]
 * @param {slot} [slot] label
 *
 * @example
 * <obg-toggle-item @click ='onClick' selected>
 *   label1
 * </obg-toggle-item>
 */
import { childMixin } from '../../mixins/multi-items'

export default {
  name: 'obg-toggle-item',
  mixins: [childMixin],
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    width: {
      type: Number
    }
  },
  methods: {
    onPressItem (e) {
      e.currentTarget.classList.add('active')
    },
    onReleaseItem (e) {
      e.currentTarget.classList.remove('active')
    }
  }
}
</script>

<style lang="scss">
/*
  @import '../../styles/common/colors.variables';
  */
</style>
