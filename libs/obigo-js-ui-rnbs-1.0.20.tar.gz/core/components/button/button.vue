<template>
  <button
    class="obg-button"
    :class="['obg-button-' + type, 'obg-button-' + size, {
      'is-disabled': disabled,
      'is-icon': icon || $slots.icon,
      'icon-only': iconOnly
    }]"
    @click.stop="handleClick"
    @touchstart="start"
    @touchend="end"
    @touchcancel="end"
    @touchleave="end"
    ref="btn"
    :disabled="disabled">
    <span class="obg-button-icon" v-if="icon || $slots.icon">
      <slot name="icon">
        <i v-if="icon" :class="'obg-icon-' + icon"></i>
      </slot>
    </span>
    <label class="obg-button-text"><slot></slot></label>
  </button>
</template>

<script>
/**
 * @class button
 * @classdesc components/button
 * @param {string} [type=default | round | square | squareroundlist | squareroundoutline | squareround | footer]
 * @param {boolean} [disabled=false]
 * @param {string} [icon]
 * @param {slot} [slot] label
 * @param {slot} [icon] icon
 *
 * @example
 * <obg-button icon="back" type="default">button</obg-button>
 * <obg-button type="default">
 *    <i class="obg-icon-back" slot="icon" />
 *    button
 * </obg-button>
 */
import {triggerBodyClickEvent} from '../../utils/event'

export default {
  name: 'obg-button',
  methods: {
    start (evt) {
      this.$refs.btn.classList.add('active')
    },
    end (evt) {
      this.$refs.btn.classList.remove('active')
    },
    handleClick (evt) {
      triggerBodyClickEvent(evt)
      this.$emit('click', evt)
    }
  },
  computed: {
    iconOnly () {
      if ((this.icon || this.$slots.icon) && typeof this.$slots.default === 'undefined') {
        return true
      }
      return false
    }
  },
  props: {
    icon: String,
    disabled: Boolean,
    type: {
      type: String,
      default: 'default',
      validator (value) {
        return ['default', 'round', 'square', 'squareroundlist', 'squareroundoutline', 'squareround', 'footer'].indexOf(value) > -1
      }
    },
    size: {
      type: String,
      default: 'normal',
      validator (value) {
        return [
          'small',
          'normal',
          'large'
        ].indexOf(value) > -1
      }
    }
  }
}
</script>

<style lang="scss">
/*
  @import '../../styles/common/colors.variables.scss';
  */

</style>
