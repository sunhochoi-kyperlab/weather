import dialog from './dialog'
export default dialog
