<template>
  <label class="obg-radio" :class="{disable: disabled, focus: focus}" @click='labelClick' @touchstart="touchstart" @touchend="touchend" @touchcancel="touchend" >
    <input type="radio" v-model="model"  @touchend.stop  @click.stop  :value="val" :disabled="disabled">
    <div><slot></slot></div>
  </label>
</template>

<script>
  /**
   * @class radio
   * @classdesc components/radio
   * @param {any} [v-model]
   * @param {number} [val] required
   * @param {number} [value] required
   * @param {boolean} [focus=false]
   * @param {boolean} [disabled=false]
   * @param {event} [input]
   *
   * @example
   * <obg-radio
   *  v-model="model"
   *  :val="1st" @input="onInput"
   *  ></obg-radio>
   *  <obg-radio
   *  v-model="model"
   *  :val="2nd" @input="onInput"
   *  ></obg-radio>
   */
  export default {
    name: 'obg-radio',
    props: {
      value: {
        required: true
      },
      val: {
        required: true
      },
      disabled: {
        type: Boolean,
        default: false
      },
      focus: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      model: {
        get () {
          return this.value
        },
        set (value) {
          this.$emit('input', value)
        }
      }
    },
    mounted () {
      // this.$parent.$on('click', this.onListItemClick)
    },
    methods: {
      labelClick (e) {
        if (!this.disabled && e.isTrusted === false) {
          this.model = this.val
        }
      },
      touchstart (e) {
        this.$el.classList.add('active')
      },
      touchend (e) {
        this.$el.classList.remove('active')
      }
//      onListItemClick () {
//        if (this.$parent.$el.classList.contains('obg-list-item') && !this.disabled) {
//          this.$emit('input', this.val)
//        }
//      }
    }
  }
</script>
<style lang="scss" scoped>
  .obg-radio{
    &.disable {
      user-select: none;
      pointer-events: none;
      opacity: 0.3;
    }
    & > input {
      display: none !important;
    }
  }




</style>
