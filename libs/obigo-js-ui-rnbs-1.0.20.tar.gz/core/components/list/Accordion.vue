<template>
  <div class='obg-accordion' >
    <div class='content' @click="handleClick"  @touchstart='down' @touchend='up' @touchcancel='up' ref='content'  >
      <div class='content-area'>
        <slot name='content'  ></slot>
      </div>
      <div class='arrow-area' >
        <i class='icon obg-icon-chevron-right' :class='{open : showChildItems}' >  </i>
      </div>
    </div>
    <transition name='show-children' @after-enter='animationEnter' @after-leave='animationLeave' >
      <div class='inner-item-container' v-if='showChildItems' >
        <slot name='children' ></slot>
      </div>
    </transition>
  </div>
</template>

<script>
/**
 * obg-accordion
 * @class accordion
 * @classdesc components/accordion
 * @param {slot} [slot] content
 * @param {slot} [slot] children
 *
 * @example
 * <obg-accordion>
 *  <div slot='content'> item content </div>
 *  <div slot='children' >
 *    <obg-list-item>item1</obg-list-item>
 *    <obg-list-item>item2</obg-list-item>
 *    <obg-list-item>item2</obg-list-item>
 *  </div>
 * </obg-accordion>
 *
 */
export default {
  name: 'obg-accordion',
  data () {
    return {
      showChildItems: false
    }
  },
  methods: {
    handleClick (e) {
      this.showChildItems = !this.showChildItems
      this.$emit('click', e)
    },
    animationEnter (el) {
      this.$parent.$emit('updateScroll')
    },
    animationLeave (el) {
      this.$parent.$emit('updateScroll')
    },
    down (e) {
      this.$refs.content.classList.add('active')
    },
    up (e) {
      this.$refs.content.classList.remove('active')
    },
    focusIn (e) {
      this.$el.classList.remove('obg-focus')
      this.$el.firstChild.classList.add('obg-focus')
    },
    focusOut (e) {
      this.$el.firstChild.classList.remove('obg-focus')
    }
  },
  mounted () {
    this.$on('focusin', this.focusIn)
    this.$on('focusout', this.focusOut)
    // check. is it portrait view?
    // accordion component can be used in portrait view.
  },
  beforeDestroy () {
    this.$off('focusin', this.focusIn)
    this.$off('focusout', this.focusOut)
  }
}
</script>
<style lang="scss" >
</style>
