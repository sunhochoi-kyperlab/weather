<template>
  <div class="obg-header">
    <div class="obg-header-column title">
      <span v-if="title">{{title}}</span>
      <slot name="title" v-else></slot>
    </div>
    <div class="obg-header-column content" :class="{'with-back': back}">
      <slot></slot>
    </div>
    <div class="obg-header-column back" v-show="back">
      <obg-button :icon="backIcon" type="default" size="small" @click="onBack"></obg-button>
    </div>
  </div>
</template>

<script>
  import button from '../button/button'

  export default {
    name: 'obg-header',
    components: {
      'obg-button': button
    },
    props: {
      title: {
        type: String,
        default: null
      },
      back: {
        type: Boolean,
        default: true
      },
      backIcon: {
        type: String,
        default: 'back-owin'
      }
    },
    methods: {
      onBack () {
        this.$emit('back')
      }
    }
  }
</script>

<style lang="scss">
</style>
