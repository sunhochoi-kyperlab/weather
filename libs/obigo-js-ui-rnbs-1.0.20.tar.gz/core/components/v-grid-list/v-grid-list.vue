<template>
    <div class='obg-v-grid-list' :class="direction">
      <div class='obg-v-grid-list-inner' >
			  <slot></slot>
      </div>
    </div>
</template>

<script>
import IScroll from '../../features/iscroll'

export default {

  name: 'obg-v-grid-list',
  props: {
    col: {
      type: Number,
      default: 3
    },
    direction: {
      type: String,
      default: 'vertical' // horizontal | vertical
    },
    scrollbars: {
      type: Boolean,
      default: true
    },
    bounce: {
      type: Boolean,
      default: true
    },
    marginBottom: {
      type: Number,
      default: 20
    }
  },
  data () {
    return {
      paddingHeight: 0,
      paddingWidth: 0
    }
  },
  methods: {
    refreshScroll () {
      if (this.$scroll) {
        this.$scroll.scrollTo(0, 0)
        this.$scroll.destroy()
      }
      this.makeScroll()
    },
    makeScroll () {
      if (this.$el.querySelectorAll('.obg-v-grid-list-inner > *').length <= this.col || this.$slots.default === undefined || this.$slots.default.length === 0) {
        return
      }
      const scroller = this.$el.children[0]
      const gridItems = this.$el.children[0].children
      const childrenCount = gridItems.length
      const gridItemHeight = gridItems[0].clientHeight
      const scrollerHeight = Math.ceil(childrenCount / this.col) * gridItemHeight + this.marginBottom
      scroller.style.height = scrollerHeight + 'px'

      let opt = {
        probeType: 2,
        scrollY: true,
        scrollX: false,
        bounce: this.bounce,
        mouseWheel: false,
        scrollbars: this.scrollbars,
        fadeScrollbars: true,
        interactiveScrollbars: false,
        click: true,
        snap: true,
        disableMouse: !('onmousedown' in window),
        disablePointer: true,
        disableTouch: !('ontouchstart' in window)
      }

      this.naviWrapper = this.$root.$el
      this.$scroll = new IScroll(this.$el, opt)
      this.$scroll.on('scrollEnd', this.scrollEnd)
    },
    scrollEnd (e) {
      if (this.$scroll.y < this.$scroll.maxScrollY) this.$emit('refresh')
    }
  },
  updated () {
    this.$nextTick(() => {
      this.refreshScroll()
    })
  },
  mounted () {
    this.$nextTick(() => {
      this.refreshScroll()
    })
  },
  activated () {
    this.$nextTick(() => {
      this.refreshScroll()
    })
  },
  beforeDestroy () {
    if (this.$scroll) {
      this.$scroll.destroy()
      this.$scroll = undefined
    }
  }

}
</script>
<style lang='scss' >
.grid-navi-container{
  position:relative;
  margin:auto;
  z-index:1;
  width:500px;
  margin-top:-78px;
  top:0;
}
</style>


