<template>
  <div class="obg-tabs-component" :class="direction">
    <div class="wrapper" ref="tabList" :class="{'first-tab-select': firstTabSelected}">
      <ul role="tab-list" class="tabs-component-tabs" :style="scrollArea">
        <li
          v-for="(tab, i) in tabs"
          :key="i"
          :class="{ 'select': tab.isActive, 'disabled': tab.isDisabled }"
          :style="tabStyle"
          class="tabs-component-tab"
          role="presentation"
          v-show="tab.isVisible"
        >
          <a
            :aria-controls="tab.hash"
            :aria-selected="tab.isActive"
            @click="onClickTab(tab.hash, $event)"
            :href="tab.hash"
            class="tabs-component-tab-a"
            role="tab"
          >
            <div v-if="tab.prefix" v-html="tab.prefix">{{tab.prefix}}</div>
            <div class="obg-tab-icon" v-if="tab.icon">
              <i v-if="tab.icon" :class="'obg-icon-' + tab.icon"></i>
            </div>
            <label class="obg-tab-text">{{tab.name}}</label>
            <div v-if="tab.prefix" v-html="tab.suffix">{{tab.suffix}}</div>
          </a>
        </li>
      </ul>
    </div>

    <div class="tabs-component-panels">
      <slot/>
    </div>
  </div>
</template>

<script>
  import IScroll from '../../features/iscroll'
  import spm from './scroll-position-manager'

  export default {
    props: {
      options: {
        type: Object,
        required: false,
        default: () => ({
          useUrlFragment: true
        })
      },
      direction: {
        type: String,
        default: 'vertical'
      },
      scroll: {
        type: Boolean,
        default: false
      },
      scrollItemCount: {
        type: Number,
        default: 6
      },
      tabHeight: {
        type: Number,
        default: 72
      },
      tabWidth: {
        type: Number,
        default: 200
      },
      default: {
        type: Number,
        default: 0
      }
    },
    data: () => ({
      tabs: [],
      activeTabHash: ''
    }),
    computed: {
      scrollArea () {
        if (this.direction === 'vertical') {
          return { 'height': (this.tabs.length * this.actualTabHeight) + 'px' }
        } else {
          return { 'width': (this.tabs.length * this.tabWidth) + 'px' }
        }
      },
      firstTabSelected () {
        return (this.tabs.length > 0) ? this.tabs[0].isActive : false
      },
      tabStyle () {
        return (this.direction === 'vertical') ? {height: this.actualTabHeight + 'px', lineHeight: this.actualTabHeight + 'px'} : {}
        // return {}
      },
      actualTabHeight () {
        return (this.scroll && this.direction === 'vertical') ? 65 : this.tabHeight
      },
      defaultIndex () {
        return this.tabs.length && this.tabs[this.default] ? this.default : 0
      }
    },
    created () {
      this.tabs = this.$children
    },
    mounted () {
      // window.addEventListener('hashchange', () => this.selectTab(window.location.hash))

      if (this.findTab(window.location.hash)) {
        this.selectTab(window.location.hash)
        return
      }

      if (this.tabs.length) {
        this.selectTab(this.tabs[this.defaultIndex].hash)
      }

      this.$nextTick(() => {
        if (this.scroll && (this.tabs.length >= this.scrollItemCount)) {
          this.makeScroll()
        }
      })
    },
    watch: {
      tabs (val, oldVal) {
        this.refreshTab()
      },
      default (val, oldVal) {
        if (val !== oldVal) this.refreshTab()
      },
      scroll (val, oldVal) {
        if (this.$scroll && val === false) {
          this.$scroll.scrollTo(0, 0)
          this.$scroll.destroy()
        }
        if (oldVal === false && val === true) this.makeScroll()
      }
    },
    activated () {
      if (this.findTab(window.location.hash)) {
        this.selectTab(window.location.hash)
        return
      }

      if (this.tabs.length) {
        this.selectTab(this.tabs[this.defaultIndex].hash)
      }
    },
    methods: {
      findTab (hash) {
        return this.tabs.find(tab => {
          return tab.hash === hash
        })
      },
      refreshTab () {
        if (this.tabs.length) {
          this.selectTab(this.tabs[this.defaultIndex].hash)
          if (this.scroll && this.$slots.default.length >= this.scrollItemCount) {
            this.refreshScroll()
          }
        }
      },
      selectTab (selectedTabHash, event) {
        // See if we should store the hash in the url fragment.
        if (event && !this.options.useUrlFragment) {
          event.preventDefault()
        }

        const selectedTab = this.findTab(selectedTabHash)

        if (!selectedTab) {
          return
        }

        if (selectedTab.isDisabled) {
          return
        }

        this.tabs.forEach(tab => {
          tab.isActive = (tab.hash === selectedTab.hash)
        })

        this.$emit('changed', {tab: selectedTab})

        this.activeTabHash = selectedTab.hash
      },

      setTabVisible (hash, visible) {
        const tab = this.findTab(hash)

        if (!tab) {
          return
        }

        tab.isVisible = visible

        if (tab.isActive) {
          // If tab is active, set a different one as active.
          tab.isActive = visible

          this.tabs.every((tab, index, array) => {
            if (tab.isVisible) {
              tab.isActive = true

              return false
            }

            return true
          })
        }
      },

      onClickTab (selectedTabHash, event) {
        const $tab = this.findTab(selectedTabHash)
        this.selectTab(selectedTabHash, event)

        $tab.$emit('click', event)
      },

      makeScroll: function () {
        const $el = this.$refs.tabList

        if (this.$slots.default === undefined || this.$slots.default.length === 0) {
          this.isEmpty = true
          return
        }
        this.isEmpty = false
        this.$scroll = new IScroll($el, {
          probeType: 2,
          scrollX: this.scroll && this.direction === 'horizontal',
          scrollY: this.scroll && this.direction === 'vertical',
          bounce: false,
          mouseWheel: false,
          scrollbars: false,
          fadeScrollbars: true,
          interactiveScrollbars: false,
          click: true,
          disableMouse: !(!('ontouchstart' in window) && ('onmousedown' in window)),
          disablePointer: true,
          disableTouch: !(('ontouchstart' in window) && ('onmousedown' in window)),
          deceleration: 0.001,
          preventDefault: false,
          dummyItem: false
        })
        this.$scroll.on('scrollEnd', this.scrollEnd)
        this.$scroll.on('scrollStart', this.scrollStart)
        var lastPos = 0
        if (this.$router) { // 팝업의 컴포넌트로 list를 생서할 시 router는 전달되지 않으므로 라우터 검사 후 라우터 사용
          lastPos = spm.get(this.listKey + this.$router.history.current.fullPath)
        }
        if (this.$router && this.$router.isBack === true && lastPos !== undefined) {
          this.$scroll.goToPage(0, lastPos.pageY, 0)    // scrollTo를 사용하면 iscroll의 pages속성을 업데이트하지않아 snap이 적용된 스크롤 동작이 정상적이지 않음.
        } else {
          this.scrollToElement(this.targetElementIndex)
        }
      },
      scrollStart () {
        // Events.$emit('v-grid:scrollstart')
      },
      scrollEnd () {
        if (this.listKey !== undefined && this.$router) {
          spm.set(this.listKey + this.$router.history.current.fullPath, this.$scroll.currentPage)
        }
        // Events.$emit('v-grid:scrollend')
      },
      scrollToElement (index) {
        if (index !== undefined && this.$slots.default[index]) {
          this.$scroll.scrollToElement(this.$slots.default[index].elm, 0)
        }
      },
      refreshScroll () {
        if (this.$scroll) {
          this.$scroll.scrollTo(0, 0)
          this.$scroll.destroy()
        }

        this.$nextTick(() => {
          this.makeScroll()
        })
      }
    }
  }
</script>
