import vTabs from './v-tabs.vue'
import vTab from './v-tab.vue'

export {
  vTabs,
  vTab
}
