<template>
  <label class='obg-checkbox' :class='{"checked": isChecked(model)}' @click='labelClick' @touchstart='touchstart' @touchend='touchend' @touchcancel='touchend' ref='label' >
    <div :class="{disabled: disabled}" class='obg-checkbox-icon' >
        <input type="checkbox" @touchend.stop  @click.stop :value='val'  :disabled="disabled" v-model="model" >
        <div>
          <svg v-if='isChecked(model)' id="Layer_1" version="1.1" viewBox="-8 -8 41 41" ><path clip-rule="evenodd" d="M21.652,3.211c-0.293-0.295-0.77-0.295-1.061,0L9.41,14.34  c-0.293,0.297-0.771,0.297-1.062,0L3.449,9.351C3.304,9.203,3.114,9.13,2.923,9.129C2.73,9.128,2.534,9.201,2.387,9.351  l-2.165,1.946C0.078,11.445,0,11.63,0,11.823c0,0.194,0.078,0.397,0.223,0.544l4.94,5.184c0.292,0.296,0.771,0.776,1.062,1.07  l2.124,2.141c0.292,0.293,0.769,0.293,1.062,0l14.366-14.34c0.293-0.294,0.293-0.777,0-1.071L21.652,3.211z" /></svg>
          <slot name="label"></slot>
        </div>
    </div>
    <span class='obg-checkbox-label' :class='{"no-content":existContent}'><slot></slot></span>
  </label>
</template>
<script>
/**
 * @class checkbox
 * @classdesc components/checkbox
 * @param {boolean} v-model=true required
 * @param {boolean} [disabled=false]
 *
 * @example
 * <obg-checkbox v-model='value' @input='func' />
 */
const isTouch = window.ontouchstart !== undefined
const EVT_START = isTouch ? 'touchstart' : 'mousedown'
const EVT_END = isTouch ? 'touchend' : 'mouseup'
const EVT_CANCEL = isTouch ? 'touchcancel' : 'mousecancel'
export default {
  name: 'obg-checkbox',
  props: {
    value: {
      required: true
    },
    val: {},
    disabled: Boolean
  },
  computed: {
    model: {
      get () {
        return this.value
      },
      set (value) {
        if (!this.disabled) {
          this.$emit('input', value)
        }
      }
    },
    existContent: {
      get () {
        return this.$slots.default === undefined
      }
    }
  },
  mounted () {
    // this.$parent.$on('click', this.onListItemClick)
    this.$refs.label.addEventListener(EVT_START, this.touchstart)
    this.$refs.label.addEventListener(EVT_END, this.touchend)
    this.$refs.label.addEventListener(EVT_CANCEL, this.touchend)
  },
  beforeDestoryed () {
    this.$refs.label.removeEventListener(EVT_START, this.touchstart)
    this.$refs.label.removeEventListener(EVT_END, this.touchend)
    this.$refs.label.removeEventListener(EVT_CANCEL, this.touchend)
  },
  methods: {
    touchstart (e) {
      this.$el.classList.add('active')
    },
    touchend (e) {
      this.$el.classList.remove('active')
    },
    labelClick (e) {
      if (!this.disabled && e.isTrusted === false) {
        this.model = !this.model
      }
    },
    isChecked (model) {
      if (typeof model === 'object') {
        const idx = model.findIndex((m) => this.val === m)
        if (idx === -1) {
          return false
        } else {
          return true
        }
      } else {
        return model
      }
    }
  }
}
</script>

<style lang="scss">
.obg-checkbox{
  .obg-checkbox-icon{
    input{
        display:none !important;
    }
  }
  input{
    touch-action: none
  }
  .obg-checkbox-label {
    padding-top:4px;
    padding-left:4px;
    font-size:22px;
    float:left;
    display:block;
    &.no-content{
      padding:0;
    }
  }
}
</style>
