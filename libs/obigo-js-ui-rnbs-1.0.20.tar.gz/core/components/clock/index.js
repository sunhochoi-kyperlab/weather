import clock from './clock'
export default clock
