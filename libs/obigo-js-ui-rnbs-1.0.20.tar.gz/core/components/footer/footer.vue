<template>
  <div
    class="obg-footer"
    :style="{'-webkit-transform': hideAnimation}"
  >
    <!--div class="obg-footer-mask" v-show=mask></div-->
    <obg-button
      class="footer-button back"
      type="footer"
      icon="back"
      @click="onClickBack"
      ref="back"
      :disabled="this.disable == 'left' || this.disable =='both' ? true : false"
    ></obg-button>
    <div class="zone-3"><slot></slot></div>
    <obg-context-menu
      class="footer-button context"
      btnType="footer"
      :icon="rightIcon"
      :disabled="this.disable == 'right' || this.disable =='both' ? true : false"
      :options="options"
      @input="onInput"
      @open="onOpen"
      @close="onClose"
      @click="onClickContextMenu"
      @jog-click="onJogClick"
      :scene="contextMenuScene"
      ref="contextMenu"
    ></obg-context-menu>
  </div>
</template>

<script>
  /**
   * obg-footer
   * @class footer
   * @classdesc components/footer
   * @param {string} [disable=none|left|right|both]
   * @param {string} [rightIcon=more]
   * @param {boolean} [mask=false]
   * @param {slot} [slot] zone-3
   * @param {function} [back] onBack cb
   * @event {string} [input]
   *
   * @example
   * <obg-footer :mask=false @back='onBack' :disable='left'>
   *   <obg-button-group v-model="btnGroup" :animated=true >
   *     obg-button-group-item icon='play'> Player </obg-button-group-item>
   *   </obg-button-group>
   * </obg-footer>
   */
  import button from '../button'
  import contextMenu from '../context-menu'
  import Events from '../../features/events'

  export default {
    name: 'obg-footer',
    components: {
      'obg-button': button,
      'obg-context-menu': contextMenu
    },
    mounted () {
      this.addFocusComponents()
      this.$refs.back.$el.addEventListener('mousedown', this.onPressStart)
      this.$refs.back.$el.addEventListener('touchstart', this.onPressStart)
      this.$refs.back.$el.addEventListener('mouseup', this.onPressEnd)
      this.$refs.back.$el.addEventListener('touchend', this.onPressEnd)
      Events.$on('list:scrollstart', () => {
        this.scrolling = true
      })
      Events.$on('list:scrollend', () => {
        this.scrolling = false
      })
    },
    beforeDestroy () {
      this.$focus._removeSceneMap(3, this.scene)
    },
    computed: {
      hideAnimation () {
        return (this.animation) ? 'translateY( ' + (this.scrolling ? 93 : 0) + 'px)' : ''
      }
    },
    data () {
      return {
        childrenCount: 0,
        isPressed: false,
        timer: null,
        scrolling: false
      }
    },
    props: {
      mask: {
        type: Boolean,
        default: false
      },
      disable: {
        type: String,
        default: 'none',
        validator (value) {
          return [
            'none',
            'left',
            'right',
            'both'
          ].indexOf(value) > -1
        }
      },
      rightIcon: {
        type: String,
        default: 'more'
      },
      options: {
        type: Array,
        default: () => [{name: '', label: ''}]
      },
      scene: {
        default: 0,
        type: Number
      },
      contextMenuScene: {
        default: 800,
        type: Number
      },
      animation: {
        default: true,
        type: Boolean
      }
    },
    methods: {
      onClickBack (evt) {
        this.$emit('back', evt)
      },
      onInput (evt) {
        this.$emit('input', evt)
      },
      onOpen () {
        this.$focus.setScene(this.contextMenuScene)
        this.$emit('open')
      },
      onClose () {
        this.$focus.setScene(this.scene)
        this.$emit('close')
      },
      onJogClick () { // keep focus mode
        this.$focus._zoneFocusMode = true
        this.$focus._componentFocusMode = true
      },
      onClickContextMenu () { // click event from focus module
        const $target = this.$refs.contextMenu.$el
        const clickEvent = new MouseEvent('click', {
          'view': window,
          'bubbles': true,
          'cancelable': false
        })
        $target.dispatchEvent(clickEvent)
      },
      onPressStart (e) {
        if (this.isPressing) return
        this.isPressing = true
        this.timer = setTimeout(() => {
          if (window.applicationFramework) {
            window.applicationFramework.applicationManager.getOwnerApplication(window.document).home()
          }
        }, 1000)
      },
      onPressEnd (e) {
        this.isPressing = false
        clearTimeout(this.timer)
      },
      refreshFocusComponents () {
        this.$focus.exitFocusMode()
        this.$focus._removeSceneMap(3, this.scene)
        this.addFocusComponents()
      },
      addFocusComponents () {
        const back = this.$children[0]
        const contextMenu = this.$refs.contextMenu
        const children = (this.$children[1].$el.classList.contains('obg-tab')) ? this.$children[1].$children : Array.from(this.$el.children[1].children)
        this.childrenCount = children.length

        if (this.childrenCount > 0) {
          let count = 0
          children.forEach((child, index) => {
            if (child.$vnode) {
              this.$focus._addComponent(child.$el, {scene: this.scene, order: count++, zone: 3, isFocus: false}, child.$vnode)
            } else {
              if (child.dataset.focusable && child.dataset.focusable === 'false') return
              this.$focus._addComponent(child, {scene: this.scene, order: count++, zone: 3, isFocus: false}, null)
            }
          })
          this.$focus._addComponent(back.$el, {scene: this.scene, order: count++, zone: 3, isFocus: false}, back.$vnode)
          this.$focus._addComponent(contextMenu.$el, {scene: this.scene, order: count, zone: 3, isFocus: false}, contextMenu.$vnode)
        } else {
          this.$focus._addComponent(back.$el, {scene: this.scene, order: 0, zone: 3, isFocus: false}, back.$vnode)
          this.$focus._addComponent(contextMenu.$el, {scene: this.scene, order: 1, zone: 3, isFocus: false}, contextMenu.$vnode)
        }
      }
    }
  }
</script>

<style lang="scss">
 /* .obg-footer{
    display:flex;
    position: absolute;
    bottom: 0px;
    justify-content: center;
    align-items: center;
    text-align: center;
    transition-duration: 200ms;
    .zone-3{
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .footer-button{
      float:left;
      z-index: 150;
    }
  }*/
</style>
