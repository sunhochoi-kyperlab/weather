import inputbox from './input-box'
export default inputbox
