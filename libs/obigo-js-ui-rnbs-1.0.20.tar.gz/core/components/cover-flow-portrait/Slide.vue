<template>
  <div
    class="obg-carousel-slide"
    :style="slideStyle"
    :class="{ 'current': isCurrent }"
    v-tap="goTo"
    :data-label-width="labelWidth"
    :data-label="label"
    :data-content="content"
  >
    <slot></slot>
  </div>
</template>

<script>
  /**
   * @class cover-slide-portrait
   * @classdesc components/cover-flow-portrait
   *
   * @example
   * <obg-cover-flow @input="onChange">
   *   <obg-cover-slide-portrait
   *    v-for="n in 11"
   *    :index="n-1"
   *    :label="'slide - ' + n"
   *    :content="n + ' - desc'"
   *   >
   *     Slide {{n}} Content
   *   </obg-cover-slide-portrait>
   * </obg-cover-flow>
   */
  import {childMixin} from '../../mixins/cover-flow'
  export default {
    name: 'obg-cover-slide-portrait',
    mixins: [childMixin],
    props: {
      label: {
        type: String
      },
      content: {
        type: String
      }
    },
    computed: {
      isCurrent () {
        return this.index === this.parent.currentIndex
      },
      slideStyle () {
        let styles = {}

        if (!this.isCurrent) {
          const rIndex = this.getSideIndex(this.parent.rightIndices)
          const lIndex = this.getSideIndex(this.parent.leftIndices)

          if (rIndex >= 0 || lIndex >= 0) {
            styles = rIndex >= 0 ? this.calculatePosition(rIndex, true) : this.calculatePosition(lIndex)
            styles.opacity = 1
            styles.visibility = 'visible'
          }

          if (this.parent.hasHiddenSlides) {
            if (this.matchIndex(this.parent.leftOutIndex)) {
              styles = this.calculatePosition(this.parent.leftIndices.length - 1)
            } else if (this.matchIndex(this.parent.rightOutIndex)) {
              styles = this.calculatePosition(this.parent.rightIndices.length - 1, true)
            }
          }
        } else {
          // styles.top = this.viewportCenter + 'px'
          styles.top = '294px'
        }

        return Object.assign(styles, {
          'border-width': this.parent.border + 'px',
          'width': this.parent.slideWidth + 'px',
          'height': this.parent.slideHeight + 'px',
          'transition': ' -webkit-transform ' + this.parent.animationSpeed + 'ms, ' +
          '               opacity ' + this.parent.animationSpeed + 'ms, ' +
          '               visibility ' + this.parent.animationSpeed + 'ms',
          '--data-label-width': this.labelWidth
        })
      }
    },
    data () {
      return {
        labelWidth: 0
      }
    },
    mounted () {
      this.viewportCenter = Math.floor((this.parent.viewport / 2 - this.parent.height / 1.32))
      if (this.parent.$el.getClientRects().length === 0) {
        this.labelWidth = 0
      } else {
        this.labelWidth = this.parent.$el.getClientRects()[0].width - this.parent.width * 2
      }
    },
    methods: {
      calculatePosition (i, positive) {
        const adjustVal = (i === 0) ? 5 : -5
        const topRemain = (this.parent.space === 'auto')
          ? parseInt((i + 1) * (this.parent.height / 0.8), 10)
          : parseInt((i + 1) * (this.parent.space), 10)
        const transform = (positive)
          ? 'translateX(-' + (150 + i * 10) + 'px)' + 'translateY(' + (topRemain + 18 + adjustVal) + 'px) translateZ(-' + (this.parent.inverseScaling + ((i + 2) * 100)) + 'px) '
          : 'translateX(-' + (150 + i * 10) + 'px)' + 'translateY(-' + (topRemain + 25 + adjustVal) + 'px) translateZ(-' + (this.parent.inverseScaling + ((i + 2) * 100)) + 'px) '
        const top = this.parent.space === 'auto' ? (this.viewportCenter) : parseInt((i + 1) * (this.parent.space))

        return {
          'transform': transform,
          '--webkit-transform': transform,
          'top': top
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .obg-carousel-slide {
    position: absolute;
    opacity: 0;
    visibility: hidden;
    border-radius: 1px;
    border-color: #000;
    border-color: rgba(0, 0, 0, 0.0);
    border-style: solid;
    background-size: cover;
    background-color: #ccc;
    display: block;
    margin: 0;
    top: 275px;
    box-sizing: border-box;
    -webkit-transition: -webkit-transform 500ms, opacity 500ms, visibility 500ms;
    & > img {
      width: 100%;
    }
    &:before, &:after{
      position: absolute;
      /*width:calc(var(--data-label-width) * 1px);*/
      width: 300px;
      min-width:150px;
      text-align:center;
      left: 200px;
      font-size: 30px;
      text-align: left;
      text-indent: 100px;
    }
    &:before {
      content: attr(data-label);
      top: 60px;
    }
    &:after {
      content: attr(data-content);
      top: 100px;
      font-size: 24px;
      display:none;
    }
    &.current {
      opacity: 1 !important;
      visibility: visible !important;
      transform: none !important;
      z-index: 99;
      &:before {
        top: 30px;
      }
      &:after {
        display:block;
      }
    }
  }

</style>
