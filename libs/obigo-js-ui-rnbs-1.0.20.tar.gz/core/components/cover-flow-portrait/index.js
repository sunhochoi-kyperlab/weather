import coverFlowPortrait from './carousel.vue'
export {coverFlowPortrait}
import coverSlide from './slide.vue'
export {coverSlide}
