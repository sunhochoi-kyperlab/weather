import Button from './button'
import ButtonGroup from './button-group'
import Checkbox from './checkbox'
import Clock from './clock'
import Combobox from './combobox'
import ContextMenu from './context-menu'
import CoverFlow from './cover-flow'
import CoverFlowPortrait from './cover-flow-portrait'
import Dialog from './dialog'
import Footer from './footer'
import GridList from './grid-list'
import Header from './header'
import Indicator from './indicator'
import InputBox from './input-box'
import List from './list'
import Numeric from './numeric'
import Playtime from './playtime'
import Popover from './popover'
import Popup from './popup'
import Progress from './progress'
import Radio from './radio'
import Range from './range'
import ScrollView from './scroll-view'
import Slider from './slider'
import Spinner from './spinner'
import Switch from './switch'
import Tab from './tab'
import Temperature from './temperature'
import Toggle from './toggle'
import VGridList from './v-grid-list'
import VTab from './v-tab'

export {
  Button,
  ButtonGroup,
  Checkbox,
  Clock,
  Combobox,
  ContextMenu,
  CoverFlow,
  CoverFlowPortrait,
  Dialog,
  Footer,
  GridList,
  Header,
  Indicator,
  InputBox,
  List,
  Numeric,
  Playtime,
  Popover,
  Popup,
  Progress,
  Radio,
  Range,
  ScrollView,
  Slider,
  Spinner,
  Switch,
  Tab,
  Temperature,
  Toggle,
  VGridList,
  VTab
}

const install = Vue => {
  Vue.component(Button.name || 'button', Button)
  Vue.component(ButtonGroup.name || 'button-group', ButtonGroup)
  Vue.component(Checkbox.name || 'checkbox', Checkbox)
  Vue.component(Clock.name || 'clock', Clock)
  Vue.component(Combobox.name || 'combobox', Combobox)
  Vue.component(ContextMenu.name || 'context-menu', ContextMenu)
  Vue.component(CoverFlow.name || 'cover-flow', CoverFlow)
  Vue.component(CoverFlowPortrait.name || 'cover-flow-portrait', CoverFlowPortrait)
  Vue.component(Dialog.name || 'dialog', Dialog)
  Vue.component(Footer.name || 'footer', Footer)
  Vue.component(GridList.name || 'grid-list', GridList)
  Vue.component(Header.name || 'header', Header)
  Vue.component(Indicator.name || 'indicator', Indicator)
  Vue.component(InputBox.name || 'input-box', InputBox)
  Vue.component(List.name || 'list', List)
  Vue.component(Numeric.name || 'numeric', Numeric)
  Vue.component(Playtime.name || 'playtime', Playtime)
  Vue.component(Popover.name || 'popover', Popover)
  Vue.component(Popup.name || 'popup', Popup)
  Vue.component(Progress.name || 'progress', Progress)
  Vue.component(Radio.name || 'radio', Radio)
  Vue.component(Range.name || 'range', Range)
  Vue.component(ScrollView.name || 'scroll-view', ScrollView)
  Vue.component(Slider.name || 'slider', Slider)
  Vue.component(Spinner.name || 'spinner', Spinner)
  Vue.component(Switch.name || 'switch', Switch)
  Vue.component(Tab.name || 'tab', Tab)
  Vue.component(Temperature.name || 'temperature', Temperature)
  Vue.component(Toggle.name || 'toggle', Toggle)
  Vue.component(VGridList.name || 'v-grid-list', VGridList)
  Vue.component(VTab.name || 'v-tab', VTab)
}

export default install
