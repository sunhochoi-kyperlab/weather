<template>
  <div
    class="obg-indicator"
    :style="{width: width + 'px'}"
  >
    <div
      v-for="n in count"
      class="dot-wrapper"
      @click="onClick"
      :index="n - 1"
      :key="n"
    >
      <i
        class="dot"
        :class="{'selected': (model === n - 1)}" />
    </div>
  </div>
</template>

<script>
  /**
   * @class indicator
   * @classdesc components/indicator
   * @param {number} [width=210]
   * @param {number} [count=3] required
   * @param {number} [value=0]
   *
   * @example
   *  <obg-indicator :count="3" :width="300">
   *  </obg-indicator>
   */
  export default{
    name: 'obg-indicator',
    props: {
      width: {
        type: Number,
        default: 210
      },
      count: {
        type: Number,
        default: 3,
        required: true
      },
      value: {
        type: Number,
        default: 0
      }
    },
    computed: {
      model: {
        get () {
          return this.value
        },
        set (value) {
          this.$emit('input', value)
        }
      }
    },
    methods: {
      onClick (e) {
        let index = e.currentTarget.getAttribute('index')
        this.model = Number(index)
      }
    }
  }
</script>
<style lang="scss" scoped>
</style>
