import contextMenu from './context-menu'
export default contextMenu
