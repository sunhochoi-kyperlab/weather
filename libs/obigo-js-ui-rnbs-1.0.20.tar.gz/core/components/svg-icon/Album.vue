<template>
    <svg viewBox="0 0 24 24">
        <path d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 14.5c-2.49 0-4.5-2.01-4.5-4.5S9.51 7.5 12 7.5s4.5 2.01 4.5 4.5-2.01 4.5-4.5 4.5zm0-5.5c-.55 0-1 .45-1 1s.45 1 1 1 1-.45 1-1-.45-1-1-1z'  fill='#ffffff' />
    </svg>
</template>

<script>
    export default{
      props: ['fill'],
      name: 'icon-album'
    }
</script>
<style lang='scss' scoped>
    svg{
      display: inline-block;
      height: 40px;
      width: 40px;
      margin:2px;
      &:active>path{
        fill:white;
      }
    }
</style>
