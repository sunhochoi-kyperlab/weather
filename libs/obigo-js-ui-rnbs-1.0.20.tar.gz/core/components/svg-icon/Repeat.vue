<template>
    <svg viewBox="0 0 24 24">
        <path d='M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4zz' fill='#ffffff' />
    </svg>
</template>

<script>
    export default{
        props:['fill'],
        name:'icon-repeat',
    }
</script>
<style scoped>
    svg{
        display: inline-block;
        height: 40px;
        width: 40px;
        margin: 6px 7px 6px 6px;
    }
</style>
