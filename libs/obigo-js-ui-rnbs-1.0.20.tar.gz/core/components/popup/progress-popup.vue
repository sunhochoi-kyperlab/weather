<template>
  <div class="overlay" @click.stop='clickPopup'>
    <div class="popup" @click.stop="clickPopup" >
      <div class="title" v-if='title' >
        <div class='title-inner' >{{title}} </div>
      </div>
      <div class='pop-contents' >
        <div class="content" >
            <div  class='text-content' >{{content}}</div>
            <div class='progress-area' >
              <div class='progress-bar' >
                <div class='bar-outline' >
                  <div class='bar-gauge' :style='{width:barWidth+"%"}'  ></div>
                </div>
              </div>
              <div class='progress-text'>
                {{barWidth}}%
              </div>
            </div>
        </div>
      </div>
      <div class="btn-area" v-if='buttons &&  buttons.length != 0' >
        <button
          @click="btn.onClick"
          v-for="(btn, index) in buttons"
          :style="getBtnWidth()"
          :index="index"
          @click.stop="onClickButton"
          @touchstart='down'
          @touchend='up'
          @touchcancel='up'
          v-obg-focus="{scene:scene, order:index, isFocus: btn.isFocus}"
          :key="index"
        >
          {{btn.label}}
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import Events from '../../features/events'
export default {
  name: 'obg-progress-popup',
  methods: {
    down (e) {
      e.target.classList.add('active')
    },
    up (e) {
      e.target.classList.remove('active')
    },
    close () {
      if (this.$root) {
        this.$root.$el.parentNode.removeChild(this.$root.$el)
        this.$root.$destroy()
        this.$root = null
      }
    },
    updateProgress (width) {
      this.barWidth = width
    },
    getBtnWidth () {
      return {
        width: (100 / this.buttons.length) + '%'
      }
    },
    clickPopup (e) {
      this.$focus.exitFocusMode()
    },
    onClickButton (e) {
      const buttonIndex = Number(e.target.getAttribute('index'))
      if (e.isTrusted) {
        this.$focus.exitFocusMode()
      } else {
        e.stopPropagation()
      }
      this.buttons[buttonIndex].onClick()
    }
  },
  data () {
    return {
      barWidth: 0,
      scene: 710,
      previousScene: 0
    }
  },
  props: {
    buttons: {
      type: Array
    },
    title: {
      type: String
    },
    content: {
      type: String
    },
    progress: {
      type: Number,
      validator: function (value) {
        return value >= 0 && value <= 100
      }
    }
  },
  mounted () {
    if (this.progress !== undefined) {
      this.updateProgress(this.progress)
    }
    const focusPos = this.$focus.getCurrentPosition()
    this.previousScene = focusPos.scene
    this.$focus.setScene(this.scene)
    this.$nextTick(() => {
      Events.$emit('popup:show', {
        type: 'popup',
        el: document.body.getElementsByClassName('popup')[0],
        prevFocusPosition: focusPos
      })
    })
    this.$root.closePopup = this.close
    this.$root.updateProgress = this.updateProgress
  },
  beforeDestroy () {
    this.$focus.setScene(this.previousScene)
    Events.$emit('popup:hide', {
      type: 'popup'
    })
  }
}
</script>

<style lang="scss" scoped >
/*
@import '../../styles/common/colors.variables';
*/

</style>
