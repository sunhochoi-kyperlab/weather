<template>
  <div class="overlay" @click.stop='clickOverlay' >
    <div class="popup" @click.stop="clickPopup" ref='popup' >
      <div class="title" v-if='title' >
        <div class='title-inner' >{{title}} </div>
      </div>
      <div class='content-area' id='component-content' v-if='typeof content === "object"' ><div class='content-inner' >{{content}}</div></div>
      <div class='content-area' id='text-content'  v-if='typeof content === "string"'><div class='content-inner text' >{{content}}</div></div>
      <div class="btn-area" v-if='buttons && buttons.length > 0' >
        <button
          v-for="(btn, index) in buttons"
          :style="getBtnWidth()"
          :index="index"
          @click.stop="onClickButton"
          @touchstart='down'
          @touchend='up'
          @touchcancel='up'
          v-obg-focus="{scene:scene, order: index, isFocus: btn.isFocus}"
          :key="index"
        >
          {{btn.label}}
              </button>
      </div>
    </div>
  </div>
</template>

<script>
  import Vue from 'vue'
  import Events from '../../features/events'

  export default {
    name: 'obg-popup',
    methods: {
      down (e) {
        e.target.classList.add('active')
      },
      up (e) {
        e.target.classList.remove('active')
      },
      close () {
        document.querySelector('#app').classList.remove('blur')
        let contentData
        let titleData
        if (this.componentContent) {
          contentData = this.componentContent.$children[0].$data
          this.componentContent.$destroy()
        }
        if (this.componentTitle) {
          titleData = this.componentTitle.$children[0].$data
          this.componentTitle.$destroy()
        }
        this.$root.$destroy()
        this.$root.$el.parentNode.removeChild(this.$root.$el)
        this.onClose(contentData, titleData)
      },
      getBtnWidth () {
        return {
          width: (100 / this.buttons.length) + '%'
        }
      },
      clickOverlay (e) {
        this.$focus.exitFocusMode()
        if (this.buttons === undefined || this.buttons.length === 0) {
          clearTimeout(this.autoCloseTimer)
          this.close()
        }
      },
      clickPopup (e) {
        this.$focus.exitFocusMode()
      },
      onClickButton (e) {
        const buttonIndex = Number(e.target.getAttribute('index'))
        if (e.isTrusted) {
          this.$focus.exitFocusMode()
        } else {
          e.stopPropagation()
        }
        let contentData
        let titleData
        if (this.componentContent) {
          contentData = this.componentContent.$children[0].$data
        }
        if (this.componentTitle) {
          titleData = this.componentTitle.$children[0].$data
        }
        this.buttons[buttonIndex].onClick(contentData, titleData)
      }
    },
    data () {
      return {
        scene: 700,
        previousScene: 0
      }
    },
    props: {
      buttons: {
        type: Array
      },
      title: {
        type: [String, Object]
      },
      content: {
        type: [String, Object]
      },
      height: {
        type: Number,
        default: 287
      },
      width: {
        type: Number,
        default: 519
      },
      onOpen: {
        type: Function,
        default: () => {}
      },
      onClose: {
        type: Function,
        default: () => {}
      },
      timeout: {
        type: Number,
        default: 5000
      }
    },
    mounted () {
      this.$refs.popup.style.width = this.width + 'px'

      var contentHeight = this.height - 2 // border top, bottom 각각 1픽셀
      if (this.title) {
        contentHeight = contentHeight - 66  // title height
      }
      if (this.buttons && this.buttons.length > 0) {
        contentHeight = contentHeight - 60  // button area height
      }

      if (!this.buttons || this.buttons.length === 0) {
        this.autoCloseTimer = setTimeout(this.close, this.timeout)
      }
      if (typeof this.content === 'object') {
        this.$el.querySelector('#component-content').style.height = contentHeight + 'px'
        this.$refs.popup.style.height = this.height + 'px'
        let props = this.content.props || {}
        props.height = this.height
        props.width = this.width
        this.componentContent = new Vue({
          el: this.$el.querySelector('.content-inner'),
          render: h => h(this.content.component, {props})
        })
      } else {
        this.$refs.popup.style.minHeight = this.height + 'px'  // text content일 경우, text 길이에 따라 자연스럽게 높이가 변할수 있게 min-height속성을 변경
      }

      if (typeof this.title === 'object') {
        let props = this.title.props || {}
        props.height = this.height
        props.width = this.width
        this.componentTitle = new Vue({
          el: this.$el.querySelector('.title-inner'),
          render: h => h(this.title.component, {props})
        })
      }

      const focusPos = this.$focus.getCurrentPosition()
      this.previousScene = focusPos.scene
      this.$focus.setScene(this.scene)
      this.$nextTick(() => {
        Events.$emit('popup:show', {
          type: 'popup',
          el: document.body.getElementsByClassName('popup')[0],
          prevFocusPosition: focusPos
        })

        document.querySelector('#app').classList.add('blur')
      })

      this.$root.closePopup = this.close
      this.onOpen()
    },
    beforeDestroy () {
      this.$focus.setScene(this.previousScene)
      Events.$emit('popup:hide', {
        type: 'popup'
      })
    }
  }
</script>
<style lang="scss" scoped >
</style>
