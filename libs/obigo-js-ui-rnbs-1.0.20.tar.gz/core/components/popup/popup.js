/**
 * @class Popup
 * @classdesc components/popup
 *
 */

import normalPopup from './popup.vue'
import progressPopup from './progress-popup.vue'
import loadingPopup from './loading-popup.vue'
import { focusInstance as focus } from '../../features/focus'
// import Events from '../../features/events'
import Vue from 'vue'
Vue.prototype.$focus = focus

let shownPopupHashMap = {}
export default function () {
  return {
    /**
     * @function show
     * @desc show popup window
     * @memberof! Popup#
     * @param {object} options                      - options to show
     * @param {string} options.type                 - type for popup. 'progres', 'loading', 'default'. default type is 'default'
     * @param {integer} options.width               - popup width sizie. px unit
     * @param {integer} options.height		    - popup height sizie. px unit
     * @param {string} options.title                - title or object to title for popup
     * @param {string} options.content              - text or object to content for popup
     * @param {array} options.buttons               - popup buttons. if no buttons, popup will be close in 5sec automatically.
     * @param {string} options.buttons.label        - popup button label
     * @param {string} options.buttons.onClick      - popup button click handler
     * @param {integer} options.timeout             - timeout(ms) to disappear automatically for no buttons popup(toast)
     * @param {integer} options.progress            - progress number. 1 ~ 10. only for 'progress' type popup.
     * @param {function} options.clickOverlay       - click event handler when click background of popup. only for 'loading' type popup.
     * @param {function} options.onClose	    - callback when popup is close<br/>if use component to create title and content, data object of content and title parameter will generated
     * @param {function} options.onOpen  	    - callback when popup is open
     * @return {object} popupObj - popup object is shown
     * @example <caption>default popup</caption>
     * import popup from 'obigo-js-ui/src/components/popup'
     * let popupObj = popup.show({
     *   title: 'popup title',
     *   content: 'popup content',
     *   buttons: [
     *     {
     *       label: 'close',
     *       onClick: () => {
     *         popupObj.close()
     *       }
     *     }
     *   ]
     * })
     *
     *
     * @example <caption>progress popup</caption>
     * import popup from 'obigo-js-ui/src/components/popup'
     * let popupObj = popup.show({
     *   type: 'progress',
     *   title: 'popup title',
     *   content: 'popup content',
     *   progress: 30,
     *   buttons: [
     *     {
     *       label: 'close',
     *       onClick: () => {
     *         popupObj.close()
     *       }
     *     }
     *   ]
     * })
     * popupObj.updateProgress(80)
     *
     *
     * @example <caption>loading popup</caption>
     * import popup from 'obigo-js-ui/src/components/popup'
     * let popupObj = popup.show({
     *   title: 'popup title',
     *   clickOverlay: () => {
     *     popupObj.close()
     *   }
     * })
     *
     * @example <caption>component popup</caption>
     * import popup from 'obigo-js-ui/src/components/popup'
     * import popupContent from 'popup-content'
     * import popupTitle from 'popup-title'
     * let popupObj = popup.show({
     *   title: 'popup title',
     *   content: {
     *     component: popupContent,
     *     props: {
     *     	...
     *     }
     *   },
     *   content: {
     *     component: popupTitle,
     *     props: {
     *     	...
     *     }
     *   },
     *   width: 500,
     *   height:300,
     *   onClose: (content, title) => {
     *	   // content is data object of content component
     *	   // title is data object of title component
     *   },
     *   buttons: [
     *     {
     *       label: 'close',
     *       onClick: () => {
     *         popupObj.close()
     *       }
     *     }
     *   ]
     * })
     *
     *
     */
    show (props) {
      const node = document.createElement('div')
      document.body.appendChild(node)
      let popup
      if (props.type === 'progress') {
        popup = progressPopup
      } else if (props.type === 'loading') {
        popup = loadingPopup
      } else {
        popup = normalPopup
      }
      let vm = new Vue({
        el: node,
        data () {
          return {props}
        },
        destroyed () {
          delete shownPopupHashMap[this._uid]
        },
        render: h => h(popup, {props})
      })

      let popupObj = { }
      popupObj.close = () => {
        vm.closePopup()
      }

      if (props.type === 'progress') {
        popupObj.updateProgress = (width) => {
          vm.updateProgress(width)
        }
      }
      shownPopupHashMap[vm._uid] = popupObj
      return popupObj
    },

    /**
     * @function closeTopPopup
     * @desc close top shown popup
     * @memberof! Popup#
     * @return {boolean} success - if close success, return true. if close fail or no shown popup, return false.
     */
    closeTopPopup () {
      var keys = Object.keys(shownPopupHashMap)
      keys.sort((a, b) => a - b)
      if (keys.length === 0) {
        return false
      } else {
        var topPopup = shownPopupHashMap[keys[keys.length - 1]]
        topPopup.close()
        delete shownPopupHashMap[keys.length - 1]
        return true
      }
    }
  }
}
