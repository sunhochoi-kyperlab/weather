 /**
  *
  *  @module directives/obg-focus
  *
  *  @example
  *  <obg-button v-obg-focus="{scene:1, order: 1}" @focusin="handler" @focusout="handler" />
  *  <obg-button v-obg-focus="{scene:1, order: 2}" />
 */
import {focusInstance} from '../features/focus'

export default {
  inserted (el, {value = {scene: 0, zone: 2}}, vnode) {
    focusInstance._addComponent(el, value, vnode)
  },
  componentUpdated (el) {
    if (!(el.disabled || el.classList.contains('disabled') || el.classList.contains('disable')) && focusInstance.focusMode) focusInstance._setComponentFocusOn()
  },
  unbind (el, {value = {scene: 0, zone: 2}}) {
    focusInstance._removeComponent(el, value)
  }
  /**
   * triggered when focus in to component
   *
   * @event focusin
   */

  /**
   * triggered when focus out from component
   *
   * @event focusout
   */
}
